# ULTRA AI source repair notes

## Changes in this repair
- Removed the sample-MP4 fallback. Video requests now fail clearly unless a provider is configured and returns a real video URL.
- Added owner-dashboard fields for a generic HTTPS video endpoint and provider key. The endpoint must return `video_url` immediately; asynchronous provider polling still requires a provider-specific adapter.
- Fixed a missing generated-job identifier in the video service.
- Fixed video status handling so failed or unverified jobs are not saved to the gallery or described as successful.
- Fixed owner authentication so the owner PIN is initialized only once and subsequent logins verify the stored PIN instead of silently resetting it.
- Removed the visible development bypass PIN.
- Allowed an invitation code to be reused only by the same bound email identity on this device, so a user can sign in again after logging out. Added an email field for invitees and enforced the chat/image/video/web/files permissions stored on each invite.
- Removed a custom debug keystore dependency; debug builds now use Android Gradle Plugin's standard debug signing.
- Replaced inaccurate setup documentation with build steps and current limitations.

## Not completed / needs external setup
- APK build and installation test: not run (Android SDK and Gradle distribution are not installed in this environment, and network access to download them is unavailable).
- Cloud owner/invite access across phones: requires a Firebase or other backend project and credentials.
- Production secret protection: requires a backend proxy; local preferences are not a secure production secret store.
- Asynchronous video-provider integrations: require a provider-specific API adapter and job polling.
