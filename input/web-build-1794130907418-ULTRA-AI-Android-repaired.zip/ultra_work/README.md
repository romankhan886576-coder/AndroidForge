# ULTRA AI — Android project

This is the native Android (Kotlin + Jetpack Compose) source project for ULTRA AI. It is source code, not an installable APK.

## Build an installable debug APK

1. Install the latest stable Android Studio and Android SDK Platform 36.1 (or the platform required by this project's Android Gradle Plugin).
2. Open this folder (`ultra_work`) in Android Studio and allow Gradle sync to finish.
3. Add your own Gemini API key in the Owner Dashboard → API Provider Keys. Do not commit API keys to source control. For production, move provider keys to a secured backend rather than distributing them in an APK.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated debug APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

A release APK for Play Store distribution needs your own signing key and release configuration. Never share your private keystore or passwords.

## Implemented in source

- Native Compose app navigation and UI screens.
- Local Room storage for conversations, messages, memories, reminders, gallery items, invite codes and audit logs.
- Gemini streaming chat and Gemini/remote image-generation request paths. A valid API key, network access, provider availability and applicable quotas are required.
- Web search service integration; search results depend on external service availability.
- Voice, file, reminders, gallery, prompt library and settings screens. Device permissions and runtime testing are still required.
- Owner PIN setup and local invite-code access. Invite feature permissions (chat, image, video, web search and files) are checked when opening those screens. Invite codes are stored in the local database on this device; they are **not** a cloud invitation system and do not synchronize to another phone. The same invited identity can sign in again on this device with its used code.
- Video generation no longer substitutes unrelated sample MP4 files or reports simulated output as AI-generated. It requires a configured HTTPS endpoint that accepts this project's JSON request and returns an immediate `video_url`. Provider-specific asynchronous job polling (for example, a default Fal.ai/Runway integration) is not included.

## Important limitations / verification

- No Firebase project configuration (`google-services.json`) or remote backend credentials are included. Cross-device owner/invite management therefore needs a separately configured backend.
- API keys entered in the app are stored in private app preferences on the device. This is not equivalent to server-side secret storage; use a backend proxy for production.
- This source package has not been built or installed in this environment. Build and device tests must be run in Android Studio before treating it as production-ready.
- AI image/video availability, costs, regional access and rate limits are controlled by the chosen external providers.
