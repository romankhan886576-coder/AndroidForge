package com.example

import com.example.data.local.ConversationEntity
import com.example.data.local.MemoryEntity
import com.example.data.local.MessageEntity
import com.example.data.local.PromptTemplateEntity
import com.example.data.model.SmartIntentClassifier
import com.example.data.model.UserIntent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class ExampleUnitTest {

    @Test
    fun `test SmartIntentClassifier multilingual rules`() {
        // Image keywords
        assertEquals(UserIntent.IMAGE_GEN, SmartIntentClassifier.classify("draw a cyberpunk robot").intent)
        assertEquals(UserIntent.IMAGE_GEN, SmartIntentClassifier.classify("photo banao").intent)
        assertEquals(UserIntent.IMAGE_GEN, SmartIntentClassifier.classify("तस्वीर बनाओ").intent)

        // Video keywords
        assertEquals(UserIntent.VIDEO_GEN, SmartIntentClassifier.classify("generate video of ocean waves").intent)
        assertEquals(UserIntent.VIDEO_GEN, SmartIntentClassifier.classify("video banao").intent)
        assertEquals(UserIntent.VIDEO_GEN, SmartIntentClassifier.classify("वीडियो बनाओ").intent)

        // Web Search
        assertEquals(UserIntent.WEB_SEARCH, SmartIntentClassifier.classify("search the web for artificial intelligence").intent)
        assertEquals(UserIntent.WEB_SEARCH, SmartIntentClassifier.classify("aaj ki taaza khabar").intent)
        assertEquals(UserIntent.WEB_SEARCH, SmartIntentClassifier.classify("latest news on technology").intent)

        // Coding
        assertEquals(UserIntent.CODING, SmartIntentClassifier.classify("fix compile error in python script").intent)
        assertEquals(UserIntent.CODING, SmartIntentClassifier.classify("write code for binary search").intent)

        // Reminders
        assertEquals(UserIntent.REMINDER, SmartIntentClassifier.classify("remind me to deploy project").intent)
        assertEquals(UserIntent.REMINDER, SmartIntentClassifier.classify("alarm lagao").intent)

        // Stories
        assertEquals(UserIntent.STORY_GEN, SmartIntentClassifier.classify("write a horror story in hindi").intent)
        assertEquals(UserIntent.STORY_GEN, SmartIntentClassifier.classify("kahani likho").intent)

        // Translations
        assertEquals(UserIntent.TRANSLATION, SmartIntentClassifier.classify("translate to hindi: Good morning").intent)

        // Image Editing
        assertEquals(UserIntent.IMAGE_EDIT, SmartIntentClassifier.classify("remove background from image").intent)

        // Video Editing
        assertEquals(UserIntent.VIDEO_EDIT, SmartIntentClassifier.classify("trim video clip").intent)
    }

    @Test
    fun `test default intent fallback`() {
        val result = SmartIntentClassifier.classify("Hello ULTRA AI, what is the meaning of life?")
        assertEquals(UserIntent.CHAT, result.intent)
        assertFalse(result.isAutoDetected)
    }

    @Test
    fun `test file analysis intent detection`() {
        val result = SmartIntentClassifier.classify("What is this document?", hasAttachment = true)
        assertEquals(UserIntent.FILE_ANALYSIS, result.intent)
        assertTrue(result.isAutoDetected)
    }

    @Test
    fun `test data entity creation and defaults`() {
        val conv = ConversationEntity(
            id = UUID.randomUUID().toString(),
            title = "Testing Conv"
        )
        assertEquals("gemini-2.0-flash", conv.modelId)
        assertFalse(conv.isPinned)

        val mem = MemoryEntity(
            id = UUID.randomUUID().toString(),
            key = "User Name",
            value = "Roman Khan"
        )
        assertEquals("General", mem.category)
        assertTrue(mem.isEnabled)

        val prompt = PromptTemplateEntity(
            id = UUID.randomUUID().toString(),
            title = "Unit Test Prompt",
            content = "Explain unit testing",
            category = "Coding"
        )
        assertFalse(prompt.isFavorite)
    }
}
