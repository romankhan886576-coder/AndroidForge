package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.LiveWebSearchService
import com.example.data.remote.SearchResultItem
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.FormattedMarkdownText
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebSearchScreen(
    repository: UltraAiRepository,
    onBack: () -> Unit,
    onOpenChatWithQuery: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val searchService = remember { LiveWebSearchService() }

    var searchQuery by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }
    var searchResults by remember { mutableStateOf<List<SearchResultItem>>(emptyList()) }
    var pageUrlInput by remember { mutableStateOf("") }
    var isReadingPage by remember { mutableStateOf(false) }
    var pageSummaryText by remember { mutableStateOf<String?>(null) }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Live Web Search & Reader", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Real-Time Internet Intelligence & Web Scraping", fontSize = 11.sp, color = UltraEmerald)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Search Input Box
            item {
                CyberCard(borderColor = UltraEmerald, glowEffect = true) {
                    Text("Search Live Internet", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraEmerald)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("e.g. Latest advancements in artificial intelligence 2026...", fontSize = 13.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = UltraEmerald) },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = {
                                    isSearching = true
                                    coroutineScope.launch {
                                        val result = searchService.searchWeb(searchQuery)
                                        isSearching = false
                                        result.onSuccess {
                                            searchResults = it
                                        }.onFailure {
                                            Toast.makeText(context, "Search failed: ${it.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }) {
                                    Icon(Icons.Default.ArrowForward, contentDescription = "Search", tint = UltraEmerald)
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = UltraEmerald,
                            unfocusedBorderColor = UltraCardBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusBadge("CONNECTED VIA HTTPS", UltraEmerald)
                        if (searchQuery.isNotBlank()) {
                            TextButton(onClick = {
                                onOpenChatWithQuery("Search the web and summarize: $searchQuery")
                            }) {
                                Text("Ask in Chat →", color = UltraCyan, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Webpage URL Reader & Summarizer
            item {
                CyberCard(borderColor = UltraCyan) {
                    Text("Read & Summarize Any Webpage", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = pageUrlInput,
                        onValueChange = { pageUrlInput = it },
                        placeholder = { Text("https://en.wikipedia.org/... or any public URL", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Link, contentDescription = null, tint = UltraCyan) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = UltraCyan,
                            unfocusedBorderColor = UltraCardBorder
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            if (!pageUrlInput.startsWith("http")) {
                                Toast.makeText(context, "Enter a valid http/https URL", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isReadingPage = true
                            pageSummaryText = null
                            coroutineScope.launch {
                                val res = searchService.readWebpage(pageUrlInput)
                                isReadingPage = false
                                res.onSuccess { content ->
                                    pageSummaryText = "📄 **Webpage Content Extracted (${content.length} chars)**:\n\n" + content.take(1200) + "..."
                                }.onFailure {
                                    Toast.makeText(context, "Failed to read page: ${it.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = UltraCyan),
                        enabled = !isReadingPage
                    ) {
                        if (isReadingPage) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = UltraDarkBg)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Reading Webpage Content...", color = UltraDarkBg)
                        } else {
                            Text("Extract & Analyze Page", color = UltraDarkBg, fontWeight = FontWeight.Bold)
                        }
                    }

                    AnimatedVisibility(visible = pageSummaryText != null) {
                        pageSummaryText?.let {
                            Column(modifier = Modifier.padding(top = 10.dp)) {
                                FormattedMarkdownText(text = it)
                            }
                        }
                    }
                }
            }

            // Search Results List
            if (isSearching) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = UltraEmerald)
                    }
                }
            } else if (searchResults.isNotEmpty()) {
                item {
                    Text("Search Results (${searchResults.size})", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                items(searchResults) { item ->
                    CyberCard(
                        modifier = Modifier.clickable {
                            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(item.url))
                            context.startActivity(browserIntent)
                        }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.source, fontSize = 11.sp, color = UltraEmerald, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.OpenInNew, contentDescription = "Open", tint = TextMuted, modifier = Modifier.size(16.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(item.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(item.snippet, fontSize = 12.sp, color = TextSecondary, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(item.url, fontSize = 11.sp, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}
