package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.ConversationEntity
import com.example.data.local.UserProfileEntity
import com.example.data.model.SmartIntentClassifier
import com.example.data.model.UserIntent
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repository: UltraAiRepository,
    currentUser: UserProfileEntity?,
    onNavigateToChat: (String) -> Unit,
    onNavigateToImageStudio: () -> Unit,
    onNavigateToVideoStudio: () -> Unit,
    onNavigateToVoice: () -> Unit,
    onNavigateToSearch: () -> Unit,
    onNavigateToFileTools: () -> Unit,
    onNavigateToPrompts: () -> Unit,
    onNavigateToReminders: () -> Unit,
    onNavigateToGallery: () -> Unit,
    onNavigateToMemory: () -> Unit,
    onNavigateToOwnerDashboard: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val conversations by repository.getConversations().collectAsState(initial = emptyList())
    var searchQuery by remember { mutableStateOf("") }
    var smartPromptInput by remember { mutableStateOf("") }
    var detectedIntent by remember { mutableStateOf<UserIntent?>(null) }

    val filteredConversations = remember(conversations, searchQuery) {
        if (searchQuery.isBlank()) conversations
        else conversations.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    LaunchedEffect(smartPromptInput) {
        if (smartPromptInput.isNotBlank()) {
            val result = SmartIntentClassifier.classify(smartPromptInput)
            detectedIntent = if (result.isAutoDetected) result.intent else null
        } else {
            detectedIntent = null
        }
    }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_ultra_ai_logo),
                            contentDescription = "ULTRA AI Core",
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "ULTRA AI",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = TextPrimary
                                )
                                StatusBadge(text = "ONLINE", color = UltraEmerald)
                            }
                            Text(
                                text = if (currentUser?.role == "OWNER") "Super Admin • Roman Khan" else "Invited • ${currentUser?.displayName ?: "User"}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                },
                actions = {
                    if (currentUser?.role == "OWNER") {
                        IconButton(onClick = onNavigateToOwnerDashboard) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = "Owner Dashboard", tint = UltraCyan)
                        }
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = TextSecondary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    coroutineScope.launch {
                        val newId = repository.createConversation("New Conversation")
                        onNavigateToChat(newId)
                    }
                },
                containerColor = UltraCyan,
                contentColor = UltraDarkBg,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "New Chat")
                    Text("New Chat", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Smart Universal Input Bar
            item {
                Spacer(modifier = Modifier.height(4.dp))
                CyberCard(borderColor = UltraCyan, glowEffect = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Smart Universal Engine",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = UltraCyan
                        )
                        detectedIntent?.let {
                            StatusBadge(text = it.label, color = Color(it.badgeColorHex))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = smartPromptInput,
                        onValueChange = { smartPromptInput = it },
                        placeholder = { Text("Ask anything, generate image/video, search web, in English/Hindi...", fontSize = 13.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = UltraCyan,
                            unfocusedBorderColor = UltraCardBorder
                        ),
                        maxLines = 3,
                        trailingIcon = {
                            if (smartPromptInput.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        val prompt = smartPromptInput
                                        smartPromptInput = ""
                                        coroutineScope.launch {
                                            val newId = repository.createConversation(prompt.take(24))
                                            repository.sendSmartMessage(newId, prompt)
                                            onNavigateToChat(newId)
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = "Execute", tint = UltraCyan)
                                }
                            }
                        }
                    )
                }
            }

            // Quick Studio Hub
            item {
                Text(
                    text = "AI Studio Hub",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HubButton(
                        title = "Image Studio",
                        subtitle = "Real AI Render",
                        icon = Icons.Default.Palette,
                        color = UltraNeonPink,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToImageStudio
                    )
                    HubButton(
                        title = "Video Studio",
                        subtitle = "Real AI MP4",
                        icon = Icons.Default.Videocam,
                        color = UltraPurple,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToVideoStudio
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HubButton(
                        title = "Voice Assistant",
                        subtitle = "Live Speech",
                        icon = Icons.Default.Mic,
                        color = UltraCyan,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToVoice
                    )
                    HubButton(
                        title = "Web Search",
                        subtitle = "Live Internet",
                        icon = Icons.Default.Public,
                        color = UltraEmerald,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToSearch
                    )
                }
            }

            // Quick Tools Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    QuickToolChip("Prompts", Icons.Default.Lightbulb, UltraAmber, onNavigateToPrompts)
                    QuickToolChip("Files", Icons.Default.Description, UltraElectricBlue, onNavigateToFileTools)
                    QuickToolChip("Reminders", Icons.Default.Alarm, UltraRose, onNavigateToReminders)
                    QuickToolChip("Gallery", Icons.Default.Collections, UltraCyan, onNavigateToGallery)
                    QuickToolChip("Memory", Icons.Default.Psychology, UltraPurple, onNavigateToMemory)
                }
            }

            // Conversation History Header with Search
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Recent Conversations",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${conversations.size} saved",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search previous chats...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = UltraCyan,
                        unfocusedBorderColor = UltraCardBorder
                    )
                )
            }

            // List of conversations
            if (filteredConversations.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = TextMuted, modifier = Modifier.size(44.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No conversations yet", color = TextSecondary, fontSize = 14.sp)
                            Text("Tap 'New Chat' or enter a smart prompt to begin.", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                items(filteredConversations, key = { it.id }) { conv ->
                    ConversationItemCard(
                        conv = conv,
                        onClick = { onNavigateToChat(conv.id) },
                        onPin = {
                            coroutineScope.launch {
                                repository.setPinned(conv.id, !conv.isPinned)
                            }
                        },
                        onDelete = {
                            coroutineScope.launch {
                                repository.deleteConversation(conv.id)
                            }
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }
}

@Composable
private fun HubButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        color = UltraSurface,
        border = BorderStroke(1.dp, color.copy(alpha = 0.35f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
            }
            Column {
                Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(subtitle, fontSize = 11.sp, color = color)
            }
        }
    }
}

@Composable
private fun QuickToolChip(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(UltraSurface)
                .border(BorderStroke(1.dp, color.copy(alpha = 0.4f)), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, color = TextSecondary)
    }
}

@Composable
private fun ConversationItemCard(
    conv: ConversationEntity,
    onClick: () -> Unit,
    onPin: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        color = UltraSurface,
        border = BorderStroke(
            1.dp,
            if (conv.isPinned) UltraCyan.copy(alpha = 0.6f) else UltraCardBorder
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = if (conv.isPinned) Icons.Default.PushPin else Icons.Default.Chat,
                    contentDescription = null,
                    tint = if (conv.isPinned) UltraCyan else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
                Column {
                    Text(
                        text = conv.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = java.text.SimpleDateFormat("MMM dd, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(conv.updatedAt)),
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            Row {
                IconButton(onClick = onPin, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Default.PushPin,
                        contentDescription = "Pin",
                        tint = if (conv.isPinned) UltraCyan else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Default.DeleteOutline,
                        contentDescription = "Delete",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
