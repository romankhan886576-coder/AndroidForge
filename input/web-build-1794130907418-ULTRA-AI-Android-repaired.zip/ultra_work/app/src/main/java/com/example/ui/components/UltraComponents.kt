package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CyberCard(
    modifier: Modifier = Modifier,
    borderColor: Color = UltraCardBorder,
    glowEffect: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                BorderStroke(
                    1.dp,
                    if (glowEffect) Brush.horizontalGradient(listOf(UltraCyan, UltraPurple))
                    else Brush.horizontalGradient(listOf(borderColor, borderColor.copy(alpha = 0.5f)))
                ),
                RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = UltraSurface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun StatusBadge(
    text: String,
    color: Color = UltraCyan,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(20.dp)),
        color = color.copy(alpha = 0.15f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Text(
                text = text,
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun PulsingAiOrb(
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    isListening: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = if (isListening) 0.95f else 1f,
        targetValue = if (isListening) 1.15f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 800 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    Box(
        modifier = modifier
            .size(size * scale)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        UltraCyan.copy(alpha = 0.9f),
                        UltraPurple.copy(alpha = 0.7f),
                        UltraNeonPink.copy(alpha = 0.4f),
                        Color.Transparent
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(size * 0.55f)
                .clip(CircleShape)
                .background(
                    Brush.sweepGradient(
                        colors = listOf(UltraCyan, UltraPurple, UltraNeonPink, UltraCyan)
                    )
                )
        )
    }
}

@Composable
fun FormattedMarkdownText(
    text: String,
    modifier: Modifier = Modifier,
    textColor: Color = TextPrimary
) {
    // Splits text into simple code blocks, headings, and paragraphs
    val lines = text.split("\n")
    var inCodeBlock = false
    val codeBlockContent = StringBuilder()

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (line in lines) {
            when {
                line.startsWith("```") -> {
                    if (inCodeBlock) {
                        // End code block
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp)),
                            color = Color(0xFF070A10),
                            border = BorderStroke(1.dp, UltraCyan.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = codeBlockContent.toString().trimEnd(),
                                modifier = Modifier.padding(12.dp),
                                color = UltraCyanGlow,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp
                            )
                        }
                        codeBlockContent.clear()
                        inCodeBlock = false
                    } else {
                        inCodeBlock = true
                        codeBlockContent.clear()
                    }
                }
                inCodeBlock -> {
                    codeBlockContent.append(line).append("\n")
                }
                line.startsWith("### ") -> {
                    Text(
                        text = line.substring(4).replace("**", ""),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = UltraCyan
                    )
                }
                line.startsWith("## ") -> {
                    Text(
                        text = line.substring(3).replace("**", ""),
                        fontSize = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = UltraCyan
                    )
                }
                line.startsWith("# ") -> {
                    Text(
                        text = line.substring(2).replace("**", ""),
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }
                line.startsWith("- ") || line.startsWith("* ") -> {
                    Row(
                        modifier = Modifier.padding(start = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("•", color = UltraCyan, fontWeight = FontWeight.Bold)
                        Text(
                            text = line.substring(2).replace("**", ""),
                            fontSize = 14.sp,
                            color = textColor,
                            lineHeight = 20.sp
                        )
                    }
                }
                line.isNotBlank() -> {
                    Text(
                        text = line.replace("**", ""),
                        fontSize = 14.sp,
                        color = textColor,
                        lineHeight = 21.sp
                    )
                }
            }
        }
    }
}
