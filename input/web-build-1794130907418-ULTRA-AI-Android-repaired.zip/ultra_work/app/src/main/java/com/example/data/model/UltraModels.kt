package com.example.data.model

enum class UserIntent(val label: String, val badgeColorHex: Long) {
    CHAT("AI Conversation", 0xFF00E5FF),
    IMAGE_GEN("AI Image Studio", 0xFFFF2E93),
    VIDEO_GEN("AI Video Studio", 0xFF8B5CF6),
    IMAGE_EDIT("Image Editing", 0xFF38EFFF),
    VIDEO_EDIT("Video Studio", 0xFF2563EB),
    WEB_SEARCH("Live Web Search", 0xFF10B981),
    STORY_GEN("Story Engine", 0xFFF59E0B),
    CODING("Code Intelligence", 0xFF6366F1),
    TRANSLATION("Neural Translator", 0xFFEC4899),
    REMINDER("Smart Reminder", 0xFF14B8A6),
    FILE_ANALYSIS("Document Analysis", 0xFFF97316)
}

data class IntentResult(
    val intent: UserIntent,
    val query: String,
    val isAutoDetected: Boolean = true,
    val details: String = ""
)

object SmartIntentClassifier {
    fun classify(prompt: String, hasAttachment: Boolean = false): IntentResult {
        val trimmed = prompt.trim()
        val lower = trimmed.lowercase()

        if (hasAttachment) {
            return IntentResult(UserIntent.FILE_ANALYSIS, trimmed, true, "Detected file attachment for analysis")
        }

        // Image Editing detection
        val editImageKeywords = listOf(
            "remove background", "remove bg", "enhance photo", "upscale image", "blur background",
            "बैकग्राउंड हटाओ", "फोटो एडिट", "bg hatao", "photo edit karo", "edit this image"
        )
        if (editImageKeywords.any { lower.contains(it) }) {
            return IntentResult(UserIntent.IMAGE_EDIT, trimmed, true, "Auto-routed to AI Image Editor")
        }

        // Video Editing detection
        val editVideoKeywords = listOf(
            "trim video", "cut video", "merge video", "video editing", "add subtitles to video",
            "video cut karo", "video trim karo"
        )
        if (editVideoKeywords.any { lower.contains(it) }) {
            return IntentResult(UserIntent.VIDEO_EDIT, trimmed, true, "Auto-routed to Video Studio")
        }

        // Image Generation detection (English, Hindi, Hinglish)
        val imageKeywords = listOf(
            "generate image", "create image", "draw an image", "picture of", "photo of",
            "draw a", "illustration of", "paint a", "sketch a", "render an image",
            "तस्वीर बनाओ", "फोटो बनाओ", "चित्र बनाओ",
            "image banao", "photo banao", "pic banao", "tasveer banao", "drawing banao"
        )
        if (imageKeywords.any { lower.contains(it) } || (lower.startsWith("image:") || lower.startsWith("draw:"))) {
            return IntentResult(UserIntent.IMAGE_GEN, trimmed, true, "Auto-routed to Real AI Image Studio")
        }

        // Video Generation detection (English, Hindi, Hinglish)
        val videoKeywords = listOf(
            "generate video", "create video", "make a video", "render video", "video of",
            "cinematic video", "video clip", "short video", "animation of",
            "वीडियो बनाओ", "वीडियो क्लिप",
            "video banao", "video create karo", "clip banao"
        )
        if (videoKeywords.any { lower.contains(it) } || lower.startsWith("video:")) {
            return IntentResult(UserIntent.VIDEO_GEN, trimmed, true, "Auto-routed to Real AI Video Studio")
        }

        // Live Web Search / Real-time info detection
        val searchKeywords = listOf(
            "search the web", "search internet", "search online", "latest news", "today news",
            "current weather", "who won today", "score today", "stock price of", "recent updates on",
            "इंटरनेट सर्च", "आज की ताजा खबर", "ताजा समाचार", "खबर",
            "web search", "google karo", "internet pe dhoondo", "search karo", "aaj ka score",
            "taaza khabar", "news", "taaza", "khabar"
        )
        if (searchKeywords.any { lower.contains(it) } || lower.startsWith("search:") || lower.startsWith("/search")) {
            return IntentResult(UserIntent.WEB_SEARCH, trimmed, true, "Live internet connectivity enabled")
        }

        // Reminder / Task detection
        val reminderKeywords = listOf(
            "remind me", "set reminder", "set an alarm", "reminder at", "remind to",
            "अलार्म लगाओ", "याद दिलाना", "रिमाइंडर", "अलार्म",
            "remind kar dena", "yaad dilana", "reminder lagao", "alarm lagao", "alarm"
        )
        if (reminderKeywords.any { lower.contains(it) }) {
            return IntentResult(UserIntent.REMINDER, trimmed, true, "Scheduled task & reminder system")
        }

        // Translation detection
        val translationKeywords = listOf(
            "translate to", "translation:", "translate into",
            "अनुवाद करो", "हिंदी में अनुवाद",
            "translate karo", "hindi me translate karo", "english me translate karo"
        )
        if (translationKeywords.any { lower.contains(it) } || lower.startsWith("translate:")) {
            return IntentResult(UserIntent.TRANSLATION, trimmed, true, "Neural multi-lingual translation")
        }

        // Coding detection
        val codeKeywords = listOf(
            "write code", "fix error", "debug this", "kotlin code", "python script", "javascript function",
            "sql query", "react component", "compose code", "write a program", "compile error", "code for"
        )
        if (codeKeywords.any { lower.contains(it) } || lower.startsWith("```") || lower.startsWith("code:")) {
            return IntentResult(UserIntent.CODING, trimmed, true, "Code Intelligence Assistant")
        }

        // Story generation detection
        val storyKeywords = listOf(
            "write a story", "horror story", "comedy story", "romantic story", "emotional story",
            "motivational story", "children story", "script for youtube", "reels script",
            "कहानी लिखो", "कथा लिखो",
            "kahani likho", "story likho", "shorts script"
        )
        if (storyKeywords.any { lower.contains(it) }) {
            return IntentResult(UserIntent.STORY_GEN, trimmed, true, "Creative Story & Script Engine")
        }

        return IntentResult(UserIntent.CHAT, trimmed, false, "Standard High-Speed AI Chat")
    }
}
