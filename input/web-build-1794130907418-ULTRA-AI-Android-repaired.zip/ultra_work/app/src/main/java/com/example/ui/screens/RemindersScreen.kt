package com.example.ui.screens

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ReminderEntity
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemindersScreen(
    repository: UltraAiRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val reminders by repository.getReminders().collectAsState(initial = emptyList())

    var addDialogOpen by remember { mutableStateOf(false) }
    var taskTitle by remember { mutableStateOf("") }
    var taskDesc by remember { mutableStateOf("") }
    var delayMinutes by remember { mutableIntStateOf(10) }

    // Android 13+ Notification permission request
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "Notification permission enabled", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Reminders & Tasks", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("AlarmManager & Exact System Notifications", fontSize = 11.sp, color = UltraRose)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { addDialogOpen = true }) {
                        Icon(Icons.Default.AddAlarm, contentDescription = "Schedule Reminder", tint = UltraRose)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (reminders.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AlarmOn, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("No Scheduled Tasks", color = TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text("Tap the '+' icon to schedule an alarm reminder.", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                items(reminders, key = { it.id }) { reminder ->
                    ReminderItemCard(
                        reminder = reminder,
                        onToggleComplete = {
                            coroutineScope.launch {
                                repository.setReminderCompleted(reminder.id, !reminder.isCompleted)
                            }
                        },
                        onDelete = {
                            coroutineScope.launch {
                                repository.deleteReminder(reminder.id)
                            }
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (addDialogOpen) {
        AlertDialog(
            onDismissRequest = { addDialogOpen = false },
            title = { Text("Schedule New Reminder") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = taskTitle,
                        onValueChange = { taskTitle = it },
                        label = { Text("Task Title") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = taskDesc,
                        onValueChange = { taskDesc = it },
                        label = { Text("Details / Note") },
                        maxLines = 2
                    )
                    Text("Trigger Alarm In:", fontSize = 12.sp, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 15, 30, 60).forEach { mins ->
                            FilterChip(
                                selected = delayMinutes == mins,
                                onClick = { delayMinutes = mins },
                                label = { Text("${mins}m") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = UltraRose,
                                    selectedLabelColor = TextPrimary
                                )
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (taskTitle.isNotBlank()) {
                        val triggerTime = System.currentTimeMillis() + (delayMinutes * 60 * 1000L)
                        coroutineScope.launch {
                            repository.addReminder(taskTitle, taskDesc, triggerTime)
                            Toast.makeText(context, "Alarm scheduled in $delayMinutes minutes!", Toast.LENGTH_SHORT).show()
                        }
                        taskTitle = ""
                        taskDesc = ""
                        addDialogOpen = false
                    }
                }) {
                    Text("Schedule Alarm", color = UltraRose, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { addDialogOpen = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ReminderItemCard(
    reminder: ReminderEntity,
    onToggleComplete: () -> Unit,
    onDelete: () -> Unit
) {
    val dateStr = SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()).format(Date(reminder.triggerTimeEpochMs))

    CyberCard(borderColor = if (reminder.isCompleted) UltraEmerald else UltraRose) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusBadge(
                text = if (reminder.isCompleted) "COMPLETED" else "SCHEDULED",
                color = if (reminder.isCompleted) UltraEmerald else UltraRose
            )
            Row {
                IconButton(onClick = onToggleComplete) {
                    Icon(
                        imageVector = if (reminder.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Toggle Complete",
                        tint = if (reminder.isCompleted) UltraEmerald else TextMuted
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = TextMuted)
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(reminder.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        if (reminder.description.isNotBlank()) {
            Spacer(modifier = Modifier.height(2.dp))
            Text(reminder.description, fontSize = 12.sp, color = TextSecondary)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.AccessTime, contentDescription = null, tint = UltraRose, modifier = Modifier.size(14.dp))
            Text(dateStr, fontSize = 11.sp, color = TextMuted)
        }
    }
}
