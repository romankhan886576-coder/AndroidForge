package com.example.data.remote

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit

data class VideoGenerationJob(
    val jobId: String,
    val prompt: String,
    val status: String, // "QUEUED", "PROCESSING", "COMPLETED", "FAILED"
    val progress: Int, // 0 - 100
    val videoUrl: String? = null,
    val localFilePath: String? = null,
    val errorMessage: String? = null,
    val durationSeconds: Int = 5,
    val aspectRatio: String = "16:9"
)

class VideoApiService(
    private val context: Context,
    private val customApiKey: String? = null,
    private val customEndpoint: String? = null
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /**
     * Submit a job only when a real video provider is configured.
     * This app does not silently substitute unrelated sample videos.
     */
    suspend fun submitVideoJob(
        prompt: String,
        aspectRatio: String = "16:9",
        durationSeconds: Int = 5,
        imageUrl: String? = null
    ): Result<VideoGenerationJob> = withContext(Dispatchers.IO) {
        val jobId = "vid_" + UUID.randomUUID().toString().take(8)
        if (prompt.isBlank()) return@withContext Result.failure(IllegalArgumentException("Please enter a video prompt."))
        if (customApiKey.isNullOrBlank() || customEndpoint.isNullOrBlank()) {
            return@withContext Result.failure(IllegalStateException(
                "Real AI video generation is not configured. Add a supported video-provider API key and endpoint in the app backend settings. No sample video will be shown as generated content."
            ))
        }

        if (!customEndpoint.startsWith("https://", ignoreCase = true)) {
            return@withContext Result.failure(IllegalArgumentException("Video provider endpoint must use HTTPS."))
        }

        try {
            val payload = JSONObject().apply {
                put("prompt", prompt)
                put("aspect_ratio", aspectRatio)
                put("duration", durationSeconds)
                if (imageUrl != null) put("image_url", imageUrl)
            }
            val request = Request.Builder()
                .url(customEndpoint)
                .header("Authorization", "Bearer $customApiKey")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Video provider returned HTTP ${response.code}: ${body.take(500)}"))
                }
                val json = JSONObject(body)
                val providerJobId = json.optString("id").ifBlank { jobId }
                val videoUrl = json.optString("video_url").takeIf { it.startsWith("https://") || it.startsWith("http://") }
                if (videoUrl == null) {
                    return@withContext Result.failure(IllegalStateException(
                        "The provider accepted the request but did not return a completed video URL. This app needs the provider's job-status API before asynchronous generation can be supported."
                    ))
                }
                Result.success(VideoGenerationJob(
                    jobId = providerJobId,
                    prompt = prompt,
                    status = "COMPLETED",
                    progress = 100,
                    videoUrl = videoUrl,
                    durationSeconds = durationSeconds,
                    aspectRatio = aspectRatio
                ))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** No simulated progress: jobs must be completed by the configured provider. */
    suspend fun pollJobStatus(job: VideoGenerationJob, currentProgress: Int): VideoGenerationJob =
        withContext(Dispatchers.IO) {
            if (!job.videoUrl.isNullOrBlank()) job.copy(status = "COMPLETED", progress = 100)
            else job.copy(status = "FAILED", progress = currentProgress.coerceIn(0, 99),
                errorMessage = "No provider status URL is configured. Generation cannot be verified.")
        }

}
