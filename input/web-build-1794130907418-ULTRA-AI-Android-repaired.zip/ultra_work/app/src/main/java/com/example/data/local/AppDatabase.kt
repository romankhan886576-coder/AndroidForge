package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Database(
    entities = [
        ConversationEntity::class,
        MessageEntity::class,
        MemoryEntity::class,
        PromptTemplateEntity::class,
        ReminderEntity::class,
        GalleryItemEntity::class,
        InviteCodeEntity::class,
        AuditLogEntity::class,
        UserProfileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun promptDao(): PromptDao
    abstract fun reminderDao(): ReminderDao
    abstract fun galleryDao(): GalleryDao
    abstract fun adminDao(): AdminDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ultra_ai_database"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Populate default built-in prompts
                            CoroutineScope(Dispatchers.IO).launch {
                                val database = getDatabase(context)
                                database.promptDao().insertPrompts(DEFAULT_PROMPTS)
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        val DEFAULT_PROMPTS = listOf(
            PromptTemplateEntity(
                id = UUID.randomUUID().toString(),
                title = "Ultimate Code Debugger & Optimizer",
                content = "Analyze this code for bugs, race conditions, memory leaks, and performance bottlenecks. Suggest optimized Kotlin/Java code with clean explanations:",
                category = "Coding",
                isBuiltIn = true
            ),
            PromptTemplateEntity(
                id = UUID.randomUUID().toString(),
                title = "Spine-Chilling Horror Story",
                content = "Write a spine-chilling, atmospheric psychological horror story set in an abandoned high-altitude observatory during a winter storm. Include plot twists and immersive sensory details:",
                category = "Stories",
                isBuiltIn = true
            ),
            PromptTemplateEntity(
                id = UUID.randomUUID().toString(),
                title = "Viral YouTube Shorts / Reels Script",
                content = "Write an ultra-engaging 60-second YouTube Shorts/Reels script about an astonishing scientific fact. Include a 3-second hook, fast-paced visual scene directions, and an irresistible call to action:",
                category = "Social & Scripts",
                isBuiltIn = true
            ),
            PromptTemplateEntity(
                id = UUID.randomUUID().toString(),
                title = "Cyberpunk AI Photorealistic Image Prompt",
                content = "A high-tech cyberpunk detective in a neon-drenched rainy mega-city alley, reflections of holographic billboards in wet puddles, cinematic lighting, 8k resolution, photorealistic Unreal Engine 5 render",
                category = "Image Gen",
                isBuiltIn = true
            ),
            PromptTemplateEntity(
                id = UUID.randomUUID().toString(),
                title = "Hindi-English Hinglish Conversational Assistant",
                content = "Mujhe Hinglish (Hindi + English) me explain karo ki neural networks aur transformers kaise kaam karte hain, with real-life daily examples.",
                category = "Hindi/Hinglish",
                isBuiltIn = true
            ),
            PromptTemplateEntity(
                id = UUID.randomUUID().toString(),
                title = "Business Pitch & Executive Summary",
                content = "Draft a persuasive executive summary and value proposition for an AI automation startup targeting enterprise logistics:",
                category = "Business",
                isBuiltIn = true
            )
        )
    }
}
