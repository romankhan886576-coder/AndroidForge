package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AuditLogEntity
import com.example.data.local.InviteCodeEntity
import com.example.data.repository.AuthRepository
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OwnerDashboardScreen(
    authRepo: AuthRepository,
    ultraAiRepo: UltraAiRepository,
    onBack: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val inviteCodes by authRepo.inviteCodes.collectAsState(initial = emptyList())
    val auditLogs by authRepo.auditLogs.collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf(0) } // 0 = Invites, 1 = Audit Logs, 2 = API Provider Keys

    // Generate Invite Dialog State
    var showCreateDialog by remember { mutableStateOf(false) }
    var targetEmail by remember { mutableStateOf("") }
    var permChat by remember { mutableStateOf(true) }
    var permImage by remember { mutableStateOf(true) }
    var permVideo by remember { mutableStateOf(true) }
    var permWeb by remember { mutableStateOf(true) }
    var permFiles by remember { mutableStateOf(true) }

    // API Key State
    var customGeminiKeyInput by remember { mutableStateOf("") }
    var videoProviderKeyInput by remember { mutableStateOf("") }
    var videoProviderEndpointInput by remember { mutableStateOf("") }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Owner Super Admin Dashboard", fontSize = 17.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                        Text("Creator & Sovereign Control Center", fontSize = 11.sp, color = UltraCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        coroutineScope.launch {
                            authRepo.logout()
                            onLogout()
                        }
                    }) {
                        Icon(Icons.Default.Logout, contentDescription = "Sign Out", tint = UltraRose)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Metrics Header Card
            CyberCard(borderColor = UltraCyan, glowEffect = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Super Admin Identity", fontSize = 11.sp, color = TextMuted)
                        Text("Roman Khan (romankhan886576@gmail.com)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    StatusBadge("SOVEREIGN OWNER", UltraCyan)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Owner account and invitation codes are stored on this device only. They will not synchronize to another phone without a configured cloud backend.",
                    fontSize = 10.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricBox("Invite Codes", "${inviteCodes.size}", UltraCyan)
                    MetricBox("Active Invites", "${inviteCodes.count { it.status == "ACTIVE" }}", UltraEmerald)
                    MetricBox("Audit Logs", "${auditLogs.size}", UltraPurple)
                }
            }

            // Tabs Selector
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = UltraSurface,
                contentColor = UltraCyan,
                indicator = {}
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Invites & Access") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Security Logs") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("API Keys") })
            }

            // Tab Content
            when (selectedTab) {
                0 -> {
                    // Invites Management
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Private Invitation Codes", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Button(
                            onClick = { showCreateDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = UltraCyan)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = UltraDarkBg, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Invite", color = UltraDarkBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(inviteCodes, key = { it.code }) { invite ->
                            InviteCodeCard(
                                invite = invite,
                                onCopy = {
                                    val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cb.setPrimaryClip(ClipData.newPlainText("Invite Code", invite.code))
                                    Toast.makeText(context, "Code ${invite.code} copied!", Toast.LENGTH_SHORT).show()
                                },
                                onRevoke = {
                                    coroutineScope.launch {
                                        authRepo.revokeInviteCode("romankhan886576@gmail.com", invite.code)
                                        Toast.makeText(context, "Code revoked", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }
                    }
                }

                1 -> {
                    // Audit Logs
                    Text("Administrative Audit Trail", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(auditLogs, key = { it.id }) { log ->
                            AuditLogItemCard(log = log)
                        }
                    }
                }

                2 -> {
                    // API Keys & Provider Settings
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            CyberCard(borderColor = UltraCyan) {
                                Text("Custom Gemini API Key", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraCyan)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "Override the Gemini API key for this installation. The key is stored in private app preferences on this device; use a secured backend for production deployments.",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = customGeminiKeyInput,
                                    onValueChange = { customGeminiKeyInput = it },
                                    label = { Text("Gemini API Key (AIzaSy...)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = UltraCyan,
                                        unfocusedBorderColor = UltraCardBorder
                                    )
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (customGeminiKeyInput.isNotBlank()) {
                                            ultraAiRepo.updateApiKey(customGeminiKeyInput.trim())
                                            Toast.makeText(context, "Custom API Key Applied!", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = UltraCyan),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Save & Apply API Key", color = UltraDarkBg, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        item {
                            CyberCard(borderColor = UltraPurple) {
                                Text("External Video Provider", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraPurple)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Optional generic endpoint. It must accept a POST request with prompt, aspect_ratio and duration, and return an immediate video_url. Asynchronous Fal.ai/Runway job polling needs a provider-specific adapter and is not included yet.", fontSize = 11.sp, color = TextSecondary)
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = videoProviderEndpointInput,
                                    onValueChange = { videoProviderEndpointInput = it },
                                    label = { Text("Provider HTTPS endpoint") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = UltraPurple, unfocusedBorderColor = UltraCardBorder)
                                )
                                OutlinedTextField(
                                    value = videoProviderKeyInput,
                                    onValueChange = { videoProviderKeyInput = it },
                                    label = { Text("Provider API key") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = UltraPurple, unfocusedBorderColor = UltraCardBorder)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        val endpoint = videoProviderEndpointInput.trim()
                                        if (!endpoint.startsWith("https://")) {
                                            Toast.makeText(context, "Please enter a valid HTTPS endpoint.", Toast.LENGTH_SHORT).show()
                                        } else if (videoProviderKeyInput.isBlank()) {
                                            Toast.makeText(context, "Please enter the provider API key.", Toast.LENGTH_SHORT).show()
                                        } else {
                                            ultraAiRepo.updateVideoProvider(videoProviderKeyInput, endpoint)
                                            Toast.makeText(context, "Video provider settings saved on this device.", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = UltraPurple),
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Save Video Provider", color = TextPrimary, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Generate Invitation Code") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = targetEmail,
                        onValueChange = { targetEmail = it },
                        label = { Text("Invited User Email (Optional)") },
                        singleLine = true
                    )
                    Text("Granted Tool Permissions:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = permChat, onCheckedChange = { permChat = it })
                        Text("AI Chat Engine", fontSize = 12.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = permImage, onCheckedChange = { permImage = it })
                        Text("Real AI Image Studio", fontSize = 12.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = permVideo, onCheckedChange = { permVideo = it })
                        Text("Real AI Video Studio", fontSize = 12.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = permWeb, onCheckedChange = { permWeb = it })
                        Text("Live Web Search", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    coroutineScope.launch {
                        val newEntity = authRepo.generateInviteCode(
                            actorEmail = "romankhan886576@gmail.com",
                            assignedEmail = targetEmail,
                            canChat = permChat,
                            canImage = permImage,
                            canVideo = permVideo,
                            canWeb = permWeb,
                            canFiles = permFiles
                        )
                        Toast.makeText(context, "Created: ${newEntity.code}", Toast.LENGTH_LONG).show()
                    }
                    showCreateDialog = false
                }) {
                    Text("Generate Code", color = UltraCyan, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun MetricBox(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Black, color = color)
        Text(label, fontSize = 10.sp, color = TextMuted)
    }
}

@Composable
private fun InviteCodeCard(
    invite: InviteCodeEntity,
    onCopy: () -> Unit,
    onRevoke: () -> Unit
) {
    CyberCard(borderColor = if (invite.status == "ACTIVE") UltraCyan else UltraRose) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusBadge(
                text = invite.status,
                color = if (invite.status == "ACTIVE") UltraCyan else UltraRose
            )
            Row {
                IconButton(onClick = onCopy) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextMuted)
                }
                if (invite.status == "ACTIVE") {
                    IconButton(onClick = onRevoke) {
                        Icon(Icons.Default.Block, contentDescription = "Revoke", tint = UltraRose)
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(invite.code, fontSize = 18.sp, fontWeight = FontWeight.Black, color = TextPrimary)
        if (invite.assignedToEmail.isNotEmpty()) {
            Text("Assigned: ${invite.assignedToEmail}", fontSize = 11.sp, color = TextSecondary)
        }
    }
}

@Composable
private fun AuditLogItemCard(log: AuditLogEntity) {
    val dateStr = SimpleDateFormat("MMM dd, HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp))
    CyberCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(log.action, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = UltraPurple)
            Text(dateStr, fontSize = 10.sp, color = TextMuted)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(log.details, fontSize = 11.sp, color = TextSecondary)
        Text("Actor: ${log.actor}", fontSize = 10.sp, color = TextMuted)
    }
}
