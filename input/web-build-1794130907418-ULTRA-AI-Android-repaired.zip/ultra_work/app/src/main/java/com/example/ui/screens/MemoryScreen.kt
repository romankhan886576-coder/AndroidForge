package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MemoryEntity
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemoryScreen(
    repository: UltraAiRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val memories by repository.getMemories().collectAsState(initial = emptyList())

    var addDialogOpen by remember { mutableStateOf(false) }
    var memoryKey by remember { mutableStateOf("") }
    var memoryValue by remember { mutableStateOf("") }
    var memoryCategory by remember { mutableStateOf("Preferences") }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI Persistent Memory", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("User-Controlled Contextual Facts (${memories.size} Active)", fontSize = 11.sp, color = UltraPurple)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { addDialogOpen = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Memory", tint = UltraPurple)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                CyberCard(borderColor = UltraPurple) {
                    Text("How AI Memory Works", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = UltraPurple)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Facts and preferences stored here are dynamically injected into ULTRA AI's neural prompts, ensuring personalized responses across all conversations. You can edit or purge memories at any time.",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }

            if (memories.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Psychology, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No Memories Stored", fontSize = 15.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                            Text("Tap '+' to save a fact, preference or project goal.", fontSize = 12.sp, color = TextMuted)
                        }
                    }
                }
            } else {
                items(memories, key = { it.id }) { mem ->
                    CyberCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusBadge(mem.category, UltraPurple)
                            IconButton(onClick = {
                                coroutineScope.launch {
                                    repository.deleteMemory(mem)
                                    Toast.makeText(context, "Memory deleted", Toast.LENGTH_SHORT).show()
                                }
                            }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = TextMuted)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(mem.key, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(mem.value, fontSize = 12.sp, color = TextSecondary)
                    }
                }

                item {
                    OutlinedButton(
                        onClick = {
                            coroutineScope.launch {
                                repository.clearMemories()
                                Toast.makeText(context, "All memories cleared", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = UltraRose),
                        border = androidx.compose.foundation.BorderStroke(1.dp, UltraRose.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Clear All AI Memories")
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (addDialogOpen) {
        AlertDialog(
            onDismissRequest = { addDialogOpen = false },
            title = { Text("Remember New Fact") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = memoryKey,
                        onValueChange = { memoryKey = it },
                        label = { Text("Topic / Key (e.g. My Coding Style)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = memoryValue,
                        onValueChange = { memoryValue = it },
                        label = { Text("Fact / Detail (e.g. Prefer Kotlin and Jetpack Compose)") },
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (memoryKey.isNotBlank() && memoryValue.isNotBlank()) {
                        coroutineScope.launch {
                            repository.addMemory(memoryKey, memoryValue, memoryCategory)
                            Toast.makeText(context, "Fact saved to AI memory!", Toast.LENGTH_SHORT).show()
                        }
                        memoryKey = ""
                        memoryValue = ""
                        addDialogOpen = false
                    }
                }) {
                    Text("Save Memory", color = UltraPurple, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { addDialogOpen = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
