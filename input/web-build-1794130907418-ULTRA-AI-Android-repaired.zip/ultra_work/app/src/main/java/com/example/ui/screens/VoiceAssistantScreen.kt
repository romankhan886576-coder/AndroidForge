package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.FormattedMarkdownText
import com.example.ui.components.PulsingAiOrb
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceAssistantScreen(
    repository: UltraAiRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isListening by remember { mutableStateOf(false) }
    var isSpeaking by remember { mutableStateOf(false) }
    var recognizedText by remember { mutableStateOf("") }
    var assistantVoiceResponse by remember { mutableStateOf("") }
    var selectedLanguageCode by remember { mutableStateOf("hi-IN") } // Default Hindi/Hinglish/English

    var tts: TextToSpeech? by remember { mutableStateOf(null) }

    DisposableEffect(Unit) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
            }
        }
        onDispose {
            tts?.stop()
            tts?.shutdown()
        }
    }

    // Speech-to-text launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        isListening = false
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val spokenMatches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = spokenMatches?.firstOrNull().orEmpty()
            if (text.isNotBlank()) {
                recognizedText = text
                assistantVoiceResponse = ""
                isSpeaking = true

                // Call Gemini for smart voice response
                coroutineScope.launch {
                    val convId = repository.createConversation("Voice: ${text.take(20)}")
                    val responseAcc = StringBuilder()
                    repository.sendSmartMessage(convId, text).collect { chunk ->
                        responseAcc.clear()
                        responseAcc.append(chunk)
                        assistantVoiceResponse = chunk
                    }
                    isSpeaking = false
                    // Read aloud response
                    tts?.speak(responseAcc.toString().replace("**", "").replace("#", ""), TextToSpeech.QUEUE_FLUSH, null, "voice_reply")
                }
            }
        }
    }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI Voice Assistant", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Real-Time Bilingual Speech Engine (Hindi / English)", fontSize = 11.sp, color = UltraCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Language Selector
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = selectedLanguageCode == "hi-IN",
                    onClick = {
                        selectedLanguageCode = "hi-IN"
                        tts?.language = Locale("hi", "IN")
                    },
                    label = { Text("हिंदी / Hinglish") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = UltraCyan,
                        selectedLabelColor = UltraDarkBg
                    )
                )
                FilterChip(
                    selected = selectedLanguageCode == "en-IN",
                    onClick = {
                        selectedLanguageCode = "en-IN"
                        tts?.language = Locale("en", "IN")
                    },
                    label = { Text("Indian English") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = UltraPurple,
                        selectedLabelColor = TextPrimary
                    )
                )
                FilterChip(
                    selected = selectedLanguageCode == "en-US",
                    onClick = {
                        selectedLanguageCode = "en-US"
                        tts?.language = Locale.US
                    },
                    label = { Text("US English") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = UltraElectricBlue,
                        selectedLabelColor = TextPrimary
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Central Glowing Pulsing AI Neural Core Orb
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(200.dp)
            ) {
                PulsingAiOrb(size = 180.dp, isListening = isListening || isSpeaking)
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(if (isListening) UltraRose else UltraSurface)
                        .clickable {
                            isListening = true
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLanguageCode)
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Listening... Speak in Hindi or English")
                            }
                            try {
                                speechLauncher.launch(intent)
                            } catch (e: Exception) {
                                isListening = false
                                Toast.makeText(context, "Voice input unavailable: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Hearing else Icons.Default.Mic,
                        contentDescription = "Speak",
                        tint = if (isListening) TextPrimary else UltraCyan,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Text(
                text = when {
                    isListening -> "Listening to your voice..."
                    isSpeaking -> "ULTRA AI is speaking back..."
                    else -> "Tap the glowing AI core to speak"
                },
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (isListening) UltraRose else UltraCyan
            )

            // User Speech Transcript
            AnimatedVisibility(visible = recognizedText.isNotEmpty()) {
                CyberCard(borderColor = UltraPurple) {
                    StatusBadge("YOU SAID", UltraPurple)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = recognizedText,
                        fontSize = 14.sp,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // AI Voice Answer
            AnimatedVisibility(visible = assistantVoiceResponse.isNotEmpty()) {
                CyberCard(borderColor = UltraCyan, glowEffect = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusBadge("ULTRA AI VOICE", UltraCyan)
                        IconButton(onClick = {
                            tts?.speak(assistantVoiceResponse.replace("**", ""), TextToSpeech.QUEUE_FLUSH, null, "replay")
                        }) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Replay Voice", tint = UltraCyan)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    FormattedMarkdownText(text = assistantVoiceResponse)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
