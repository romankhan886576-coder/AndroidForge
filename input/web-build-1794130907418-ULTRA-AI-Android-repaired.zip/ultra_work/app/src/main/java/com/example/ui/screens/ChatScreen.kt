package com.example.ui.screens

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.MessageEntity
import com.example.data.model.SmartIntentClassifier
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.FormattedMarkdownText
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    conversationId: String,
    repository: UltraAiRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val messages by repository.getMessages(conversationId).collectAsState(initial = emptyList())
    val listState = rememberLazyListState()

    var inputPrompt by remember { mutableStateOf("") }
    var attachedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isStreaming by remember { mutableStateOf(false) }
    var currentStreamingChunk by remember { mutableStateOf("") }
    var activeStreamingJob by remember { mutableStateOf<Job?>(null) }
    var renameDialogOpen by remember { mutableStateOf(false) }
    var newTitleInput by remember { mutableStateOf("") }

    // Text to Speech
    var tts: TextToSpeech? by remember { mutableStateOf(null) }
    DisposableEffect(Unit) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("en", "IN")
            }
        }
        onDispose {
            tts?.stop()
            tts?.shutdown()
        }
    }

    // Photo Picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val bitmap = if (Build.VERSION.SDK_INT < 28) {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                } else {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source)
                }
                attachedBitmap = bitmap
            } catch (e: Exception) {
                Toast.makeText(context, "Could not load image: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Speech to text launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val spokenMatches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = spokenMatches?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                inputPrompt = if (inputPrompt.isBlank()) spokenText else "$inputPrompt $spokenText"
            }
        }
    }

    // Auto-scroll when messages update or streaming
    LaunchedEffect(messages.size, currentStreamingChunk) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "ULTRA AI Assistant",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (isStreaming) UltraCyan else UltraEmerald)
                            )
                            Text(
                                text = if (isStreaming) "Streaming Response..." else "Ready (Gemini 2.0 Flash)",
                                fontSize = 11.sp,
                                color = if (isStreaming) UltraCyan else TextSecondary
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { renameDialogOpen = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Rename Chat", tint = TextSecondary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(UltraSurface)
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                // Attached image preview
                AnimatedVisibility(visible = attachedBitmap != null) {
                    attachedBitmap?.let { bmp ->
                        Row(
                            modifier = Modifier
                                .padding(bottom = 8.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(UltraSurfaceVariant)
                                .padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Attached Image",
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(6.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Text("Image attached for analysis", fontSize = 12.sp, color = TextPrimary)
                            Spacer(modifier = Modifier.weight(1f))
                            IconButton(onClick = { attachedBitmap = null }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Remove", tint = UltraRose)
                            }
                        }
                    }
                }

                // Input row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Attachment button
                    IconButton(
                        onClick = { photoPickerLauncher.launch("image/*") },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(UltraSurfaceVariant)
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Attach Image", tint = UltraCyan)
                    }

                    // Voice Speech-to-Text button
                    IconButton(
                        onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in English, Hindi, or Hinglish...")
                            }
                            try {
                                speechLauncher.launch(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Voice input unavailable: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(UltraSurfaceVariant)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Speak", tint = UltraPurple)
                    }

                    // Text Input
                    OutlinedTextField(
                        value = inputPrompt,
                        onValueChange = { inputPrompt = it },
                        placeholder = { Text("Ask, generate, or search in English/Hindi...", fontSize = 13.sp) },
                        modifier = Modifier.weight(1f),
                        maxLines = 4,
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = UltraCyan,
                            unfocusedBorderColor = UltraCardBorder,
                            focusedContainerColor = UltraDarkBg,
                            unfocusedContainerColor = UltraDarkBg
                        )
                    )

                    // Send / Stop button
                    if (isStreaming) {
                        IconButton(
                            onClick = {
                                activeStreamingJob?.cancel()
                                isStreaming = false
                                currentStreamingChunk = ""
                            },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(UltraRose)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = "Stop", tint = TextPrimary)
                        }
                    } else {
                        IconButton(
                            onClick = {
                                if (inputPrompt.isNotBlank() || attachedBitmap != null) {
                                    val prompt = inputPrompt
                                    val bmp = attachedBitmap
                                    inputPrompt = ""
                                    attachedBitmap = null
                                    isStreaming = true
                                    currentStreamingChunk = ""

                                    activeStreamingJob = coroutineScope.launch {
                                        repository.sendSmartMessage(
                                            conversationId = conversationId,
                                            userPrompt = prompt,
                                            bitmap = bmp
                                        ).collect { chunk ->
                                            currentStreamingChunk = chunk
                                        }
                                        isStreaming = false
                                        currentStreamingChunk = ""
                                    }
                                }
                            },
                            enabled = inputPrompt.isNotBlank() || attachedBitmap != null,
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(if (inputPrompt.isNotBlank() || attachedBitmap != null) UltraCyan else UltraSurfaceVariant)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = UltraDarkBg)
                        }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                ChatMessageItem(
                    message = msg,
                    onSpeak = { text ->
                        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ultra_tts")
                    },
                    onCopy = { text ->
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("ULTRA AI", text))
                        Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    onShare = { text ->
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, text)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share AI Response"))
                    }
                )
            }

            // Real-time live streaming bubble
            if (isStreaming && currentStreamingChunk.isNotBlank()) {
                item {
                    StreamingMessageBubble(content = currentStreamingChunk)
                }
            }
        }
    }

    // Rename Dialog
    if (renameDialogOpen) {
        AlertDialog(
            onDismissRequest = { renameDialogOpen = false },
            title = { Text("Rename Conversation") },
            text = {
                OutlinedTextField(
                    value = newTitleInput,
                    onValueChange = { newTitleInput = it },
                    label = { Text("Conversation Title") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newTitleInput.isNotBlank()) {
                            coroutineScope.launch {
                                repository.renameConversation(conversationId, newTitleInput)
                            }
                        }
                        renameDialogOpen = false
                    }
                ) {
                    Text("Save", color = UltraCyan)
                }
            },
            dismissButton = {
                TextButton(onClick = { renameDialogOpen = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ChatMessageItem(
    message: MessageEntity,
    onSpeak: (String) -> Unit,
    onCopy: (String) -> Unit,
    onShare: (String) -> Unit
) {
    val isUser = message.role == "user"

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        // Intent tag for assistant responses
        if (!isUser && message.intentTag.isNotEmpty() && message.intentTag != "chat") {
            Row(modifier = Modifier.padding(bottom = 4.dp)) {
                StatusBadge(
                    text = message.intentTag.uppercase(),
                    color = when (message.intentTag) {
                        "image_gen" -> UltraNeonPink
                        "video_gen" -> UltraPurple
                        "web_search" -> UltraEmerald
                        "reminder" -> UltraRose
                        else -> UltraCyan
                    }
                )
            }
        }

        Surface(
            modifier = Modifier
                .widthIn(max = 340.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                ),
            color = if (isUser) UltraCyan else UltraSurface,
            border = if (!isUser) androidx.compose.foundation.BorderStroke(1.dp, UltraCardBorder) else null
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // If message has media URL (Image or Video)
                if (!message.mediaUrl.isNullOrEmpty()) {
                    if (message.intentTag == "video_gen") {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(10.dp)),
                            color = Color.Black
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.PlayCircle,
                                    contentDescription = "Play Video",
                                    tint = UltraCyan,
                                    modifier = Modifier.size(54.dp)
                                )
                                Text(
                                    text = "Tap Video Studio for playback",
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .padding(8.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    } else {
                        AsyncImage(
                            model = message.mediaUrl,
                            contentDescription = "Generated Image",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }

                // Text body
                if (isUser) {
                    Text(
                        text = message.content,
                        fontSize = 14.sp,
                        color = UltraDarkBg,
                        lineHeight = 20.sp,
                        fontWeight = FontWeight.Medium
                    )
                } else {
                    FormattedMarkdownText(text = message.content)
                }

                // Citations list if present
                if (!message.citationsJson.isNullOrEmpty()) {
                    val citations = remember(message.citationsJson) {
                        val list = mutableListOf<Pair<String, String>>()
                        try {
                            val arr = JSONArray(message.citationsJson)
                            for (i in 0 until minOf(arr.length(), 4)) {
                                val item = arr.getString(i).split("|")
                                val title = item.getOrNull(0) ?: "Source"
                                val url = item.getOrNull(1) ?: ""
                                list.add(title to url)
                            }
                        } catch (e: Exception) {
                            // ignore
                        }
                        list
                    }

                    if (citations.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Sources & Citations:", fontSize = 11.sp, color = UltraEmerald, fontWeight = FontWeight.Bold)
                        citations.forEach { (title, url) ->
                            Text(
                                text = "• $title\n  $url",
                                fontSize = 10.sp,
                                color = TextMuted,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Action icons for assistant messages (TTS Speak, Copy, Share)
        if (!isUser) {
            Row(
                modifier = Modifier.padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(onClick = { onSpeak(message.content) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.VolumeUp, contentDescription = "Read Aloud", tint = TextMuted, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = { onCopy(message.content) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextMuted, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = { onShare(message.content) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = TextMuted, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun StreamingMessageBubble(content: String) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.Start
    ) {
        Row(modifier = Modifier.padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            StatusBadge(text = "LIVE STREAMING", color = UltraCyan)
        }
        Surface(
            modifier = Modifier
                .widthIn(max = 340.dp)
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 4.dp)),
            color = UltraSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, UltraCyan.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                FormattedMarkdownText(text = content)
            }
        }
    }
}
