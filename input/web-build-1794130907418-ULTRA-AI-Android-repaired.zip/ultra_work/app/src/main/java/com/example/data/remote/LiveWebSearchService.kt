package com.example.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class SearchResultItem(
    val title: String,
    val snippet: String,
    val url: String,
    val source: String = ""
)

class LiveWebSearchService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /**
     * Performs a real internet search across supported engines
     */
    suspend fun searchWeb(query: String): Result<List<SearchResultItem>> = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            // DuckDuckGo instant API + HTML search endpoint
            val instantUrl = "https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1"

            val instantRequest = Request.Builder()
                .url(instantUrl)
                .header("User-Agent", "Mozilla/5.0 (Android; Mobile; rv:120.0) Gecko/120.0 Firefox/120.0")
                .build()

            val items = mutableListOf<SearchResultItem>()

            client.newCall(instantRequest).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    if (body.isNotEmpty()) {
                        val json = JSONObject(body)
                        val heading = json.optString("Heading")
                        val abstractText = json.optString("AbstractText")
                        val abstractUrl = json.optString("AbstractURL")
                        val source = json.optString("AbstractSource")

                        if (abstractText.isNotEmpty() && abstractUrl.isNotEmpty()) {
                            items.add(
                                SearchResultItem(
                                    title = if (heading.isNotEmpty()) heading else query,
                                    snippet = abstractText,
                                    url = abstractUrl,
                                    source = source.ifEmpty { "DuckDuckGo / Wikipedia" }
                                )
                            )
                        }

                        val related = json.optJSONArray("RelatedTopics")
                        if (related != null) {
                            for (i in 0 until minOf(related.length(), 6)) {
                                val item = related.optJSONObject(i) ?: continue
                                val text = item.optString("Text")
                                val firstUrl = item.optString("FirstURL")
                                if (text.isNotEmpty() && firstUrl.isNotEmpty()) {
                                    items.add(
                                        SearchResultItem(
                                            title = text.take(60),
                                            snippet = text,
                                            url = firstUrl,
                                            source = "Web"
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // If instant API had few results, perform HTML web search
            if (items.size < 3) {
                val htmlSearchUrl = "https://html.duckduckgo.com/html/?q=$encoded"
                val htmlRequest = Request.Builder()
                    .url(htmlSearchUrl)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                    .build()

                try {
                    client.newCall(htmlRequest).execute().use { res ->
                        if (res.isSuccessful) {
                            val html = res.body?.string().orEmpty()
                            val linkPattern = Pattern.compile("<a class=\"result__url\" href=\"(.*?)\">(.*?)<\\/a>", Pattern.DOTALL)
                            val snippetPattern = Pattern.compile("<a class=\"result__snippet.*?>(.*?)<\\/a>", Pattern.DOTALL)

                            val linkMatcher = linkPattern.matcher(html)
                            val snippetMatcher = snippetPattern.matcher(html)

                            var count = 0
                            while (linkMatcher.find() && snippetMatcher.find() && count < 6) {
                                val rawUrl = linkMatcher.group(1).orEmpty().trim()
                                val rawTitle = linkMatcher.group(2).orEmpty().replace(Regex("<.*?>"), "").trim()
                                val rawSnippet = snippetMatcher.group(1).orEmpty().replace(Regex("<.*?>"), "").trim()

                                // Unescape ddg url
                                val cleanUrl = if (rawUrl.contains("uddg=")) {
                                    java.net.URLDecoder.decode(rawUrl.substringAfter("uddg=").substringBefore("&"), "UTF-8")
                                } else rawUrl

                                if (cleanUrl.startsWith("http") && !items.any { it.url == cleanUrl }) {
                                    items.add(
                                        SearchResultItem(
                                            title = if (rawTitle.isNotEmpty()) rawTitle else "Web Result",
                                            snippet = rawSnippet,
                                            url = cleanUrl,
                                            source = "Live Internet"
                                        )
                                    )
                                    count++
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Ignore HTML parse fallback errors
                }
            }

            Result.success(items)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Reads and extracts readable text from any accessible webpage
     */
    suspend fun readWebpage(url: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("HTTP ${response.code} reading webpage"))
                }
                val html = response.body?.string().orEmpty()
                // Strip scripts and styles
                var clean = html.replace(Regex("(?s)<script.*?</script>"), " ")
                clean = clean.replace(Regex("(?s)<style.*?</style>"), " ")
                clean = clean.replace(Regex("<.*?>"), " ")
                clean = clean.replace(Regex("\\s+"), " ").trim()
                Result.success(clean.take(4000))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
