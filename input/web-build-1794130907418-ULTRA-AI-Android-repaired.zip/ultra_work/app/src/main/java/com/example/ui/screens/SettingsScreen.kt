package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.AuthRepository
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    repository: UltraAiRepository,
    authRepo: AuthRepository,
    onBack: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedModel by remember { mutableStateOf("gemini-2.0-flash") }
    var selectedLanguage by remember { mutableStateOf("Hinglish (Hindi + English)") }

    var backupJsonString by remember { mutableStateOf("") }
    var restoreJsonInput by remember { mutableStateOf("") }
    var showRestoreDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("System Settings", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Engine Configuration & Data Management", fontSize = 11.sp, color = UltraCyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Model Selection
            CyberCard(borderColor = UltraCyan) {
                Text("Default AI Intelligence Engine", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraCyan)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Select the primary neural model for streaming conversations and reasoning.", fontSize = 11.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(10.dp))

                listOf("gemini-2.0-flash" to "Gemini 2.0 Flash (Fastest / Ultra Low Latency)", "gemini-1.5-pro" to "Gemini 1.5 Pro (Complex Deep Reasoning)").forEach { (id, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = selectedModel == id,
                            onClick = { selectedModel = id }
                        )
                        Text(label, fontSize = 12.sp, color = TextPrimary)
                    }
                }
            }

            // Language & Dialect
            CyberCard(borderColor = UltraPurple) {
                Text("Language & Natural Dialect", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraPurple)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Native conversational understanding for South Asian and global multilingual users.", fontSize = 11.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(8.dp))

                listOf("Hinglish (Hindi + English)", "Pure Hindi (शुद्ध हिंदी)", "English (US / Global)").forEach { lang ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = selectedLanguage == lang,
                            onClick = { selectedLanguage = lang }
                        )
                        Text(lang, fontSize = 12.sp, color = TextPrimary)
                    }
                }
            }

            // Backup & Data Restore
            CyberCard(borderColor = UltraEmerald) {
                Text("Secure Backup & Data Restore", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraEmerald)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Export all conversations, custom prompts, and memory to JSON.", fontSize = 11.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val json = repository.exportBackupJson()
                                backupJsonString = json
                                val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cb.setPrimaryClip(ClipData.newPlainText("ULTRA_AI_Backup", json))
                                Toast.makeText(context, "Backup copied to clipboard!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = UltraEmerald)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, tint = UltraDarkBg)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export JSON", color = UltraDarkBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { showRestoreDialog = true },
                        modifier = Modifier.weight(1f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, UltraEmerald)
                    ) {
                        Icon(Icons.Default.Upload, contentDescription = null, tint = UltraEmerald)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Restore Data", color = UltraEmerald, fontSize = 12.sp)
                    }
                }
            }

            // About ULTRA AI
            CyberCard {
                Text("About ULTRA AI", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Version: 1.0.0 Production Release", fontSize = 12.sp, color = TextSecondary)
                Text("Developer: Roman Khan (romankhan886576@gmail.com)", fontSize = 12.sp, color = TextSecondary)
                Text("Architecture: Native Android Kotlin • Jetpack Compose • Room DB", fontSize = 12.sp, color = TextSecondary)
                Text("Hardware: Multithreaded Coroutines • SSE Streaming • Open Graphics", fontSize = 12.sp, color = TextSecondary)
            }

            // Sign out button
            Button(
                onClick = {
                    coroutineScope.launch {
                        authRepo.logout()
                        onLogout()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = UltraRose)
            ) {
                Icon(Icons.Default.Logout, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Sign Out of ULTRA AI", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Restore From Backup JSON") },
            text = {
                OutlinedTextField(
                    value = restoreJsonInput,
                    onValueChange = { restoreJsonInput = it },
                    placeholder = { Text("Paste JSON backup data here...") },
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    coroutineScope.launch {
                        val success = repository.importBackupJson(restoreJsonInput)
                        if (success) {
                            Toast.makeText(context, "Data restored successfully!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Invalid backup format.", Toast.LENGTH_SHORT).show()
                        }
                    }
                    showRestoreDialog = false
                }) {
                    Text("Restore", color = UltraEmerald)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
