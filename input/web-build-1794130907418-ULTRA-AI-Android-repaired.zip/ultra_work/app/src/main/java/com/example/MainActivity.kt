package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.flowOf
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.local.AppDatabase
import com.example.data.repository.AuthRepository
import com.example.data.repository.UltraAiRepository
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = AppDatabase.getDatabase(applicationContext)
        val authRepository = AuthRepository(db.adminDao(), applicationContext)
        val ultraAiRepository = UltraAiRepository(applicationContext, db)

        setContent {
            MyApplicationTheme {
                val navController = rememberNavController()
                val currentUser by authRepository.currentUser.collectAsState(initial = null)
                val permissionsFlow = remember(currentUser?.email) {
                    currentUser?.takeIf { it.role == "INVITED_USER" }?.let {
                        authRepository.permissionsForUser(it.email)
                    } ?: flowOf(null)
                }
                val invitePermissions by permissionsFlow.collectAsState(initial = null)

                // Route automatically if auth state changes
                LaunchedEffect(currentUser) {
                    if (currentUser == null) {
                        navController.navigate("auth") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = if (currentUser != null) "home" else "auth",
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable("auth") {
                        AuthScreen(
                            authRepo = authRepository,
                            onAuthenticated = {
                                navController.navigate("home") {
                                    popUpTo("auth") { inclusive = true }
                                }
                            }
                        )
                    }

                    composable("home") {
                        HomeScreen(
                            repository = ultraAiRepository,
                            currentUser = currentUser,
                            onNavigateToChat = { convId -> navController.navigate("chat/$convId") },
                            onNavigateToImageStudio = { navController.navigate("image_studio") },
                            onNavigateToVideoStudio = { navController.navigate("video_studio") },
                            onNavigateToVoice = { navController.navigate("voice_assistant") },
                            onNavigateToSearch = { navController.navigate("web_search") },
                            onNavigateToFileTools = { navController.navigate("file_tools") },
                            onNavigateToPrompts = { navController.navigate("prompt_library") },
                            onNavigateToReminders = { navController.navigate("reminders") },
                            onNavigateToGallery = { navController.navigate("gallery") },
                            onNavigateToMemory = { navController.navigate("memory") },
                            onNavigateToOwnerDashboard = { navController.navigate("owner_dashboard") },
                            onNavigateToSettings = { navController.navigate("settings") }
                        )
                    }

                    composable(
                        route = "chat/{conversationId}",
                        arguments = listOf(navArgument("conversationId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val convId = backStackEntry.arguments?.getString("conversationId") ?: "default"
                        if (currentUser?.role == "OWNER" || invitePermissions?.canUseChat == true) {
                            ChatScreen(
                                conversationId = convId,
                                repository = ultraAiRepository,
                                onBack = { navController.popBackStack() }
                            )
                        } else AccessDeniedFeature { navController.popBackStack() }
                    }

                    composable("image_studio") {
                        if (currentUser?.role == "OWNER" || invitePermissions?.canUseImageGen == true) {
                            ImageStudioScreen(repository = ultraAiRepository, onBack = { navController.popBackStack() })
                        } else AccessDeniedFeature { navController.popBackStack() }
                    }

                    composable("video_studio") {
                        if (currentUser?.role == "OWNER" || invitePermissions?.canUseVideoGen == true) {
                            VideoStudioScreen(repository = ultraAiRepository, onBack = { navController.popBackStack() })
                        } else AccessDeniedFeature { navController.popBackStack() }
                    }

                    composable("voice_assistant") {
                        VoiceAssistantScreen(
                            repository = ultraAiRepository,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("web_search") {
                        if (currentUser?.role == "OWNER" || invitePermissions?.canUseWebSearch == true) {
                            WebSearchScreen(
                                repository = ultraAiRepository,
                                onBack = { navController.popBackStack() },
                                onOpenChatWithQuery = { query -> navController.navigate("home") }
                            )
                        } else AccessDeniedFeature { navController.popBackStack() }
                    }

                    composable("file_tools") {
                        if (currentUser?.role == "OWNER" || invitePermissions?.canUseFiles == true) {
                            FileToolsScreen(
                                repository = ultraAiRepository,
                                onBack = { navController.popBackStack() },
                                onOpenChatWithContent = { content -> navController.navigate("home") }
                            )
                        } else AccessDeniedFeature { navController.popBackStack() }
                    }

                    composable("prompt_library") {
                        PromptLibraryScreen(
                            repository = ultraAiRepository,
                            onBack = { navController.popBackStack() },
                            onUsePrompt = { promptText ->
                                navController.navigate("home")
                            }
                        )
                    }

                    composable("reminders") {
                        RemindersScreen(
                            repository = ultraAiRepository,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("gallery") {
                        GalleryScreen(
                            repository = ultraAiRepository,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("memory") {
                        MemoryScreen(
                            repository = ultraAiRepository,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("owner_dashboard") {
                        if (currentUser?.role == "OWNER") {
                            OwnerDashboardScreen(
                                authRepo = authRepository,
                                ultraAiRepo = ultraAiRepository,
                                onBack = { navController.popBackStack() },
                                onLogout = {
                                    navController.navigate("auth") { popUpTo(0) { inclusive = true } }
                                }
                            )
                        } else AccessDeniedFeature { navController.popBackStack() }
                    }

                    composable("settings") {
                        SettingsScreen(
                            repository = ultraAiRepository,
                            authRepo = authRepository,
                            onBack = { navController.popBackStack() },
                            onLogout = {
                                navController.navigate("auth") {
                                    popUpTo(0) { inclusive = true }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AccessDeniedFeature(onBack: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Access not granted", style = MaterialTheme.typography.headlineSmall)
            Spacer(modifier = Modifier.height(8.dp))
            Text("The Owner has not enabled this feature for your invitation.")
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onBack) { Text("Go back") }
        }
    }
}
