package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import com.example.data.local.*
import com.example.data.model.SmartIntentClassifier
import com.example.data.model.UserIntent
import com.example.data.remote.GeminiApiService
import com.example.data.remote.LiveWebSearchService
import com.example.data.remote.VideoApiService
import com.example.data.remote.VideoGenerationJob
import com.example.receiver.ReminderScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class UltraAiRepository(
    private val context: Context,
    private val db: AppDatabase,
    customApiKey: String? = null
) {
    private val apiPrefs = context.applicationContext.getSharedPreferences("ultra_ai_settings", Context.MODE_PRIVATE)
    private var customApiKey: String? = customApiKey ?: apiPrefs.getString("gemini_api_key", null)
    private var geminiApiService = GeminiApiService(this.customApiKey)
    private val webSearchService = LiveWebSearchService()
    private var videoApiService = VideoApiService(
        context,
        apiPrefs.getString("video_api_key", null),
        apiPrefs.getString("video_endpoint", null)
    )

    fun updateApiKey(apiKey: String) {
        val cleaned = apiKey.trim()
        customApiKey = cleaned.takeIf { it.isNotEmpty() }
        apiPrefs.edit().putString("gemini_api_key", customApiKey).apply()
        geminiApiService = GeminiApiService(customApiKey)
    }

    fun updateVideoProvider(apiKey: String, endpoint: String) {
        val cleanedKey = apiKey.trim()
        val cleanedEndpoint = endpoint.trim()
        apiPrefs.edit()
            .putString("video_api_key", cleanedKey)
            .putString("video_endpoint", cleanedEndpoint)
            .apply()
        videoApiService = VideoApiService(
            context,
            cleanedKey.takeIf { it.isNotEmpty() },
            cleanedEndpoint.takeIf { it.isNotEmpty() }
        )
    }

    // Conversations
    fun getConversations(): Flow<List<ConversationEntity>> = db.conversationDao().getAllConversations()
    fun searchConversations(query: String): Flow<List<ConversationEntity>> = db.conversationDao().searchConversations(query)

    suspend fun createConversation(title: String = "New Conversation"): String {
        val id = UUID.randomUUID().toString()
        val conv = ConversationEntity(
            id = id,
            title = title,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        db.conversationDao().insertConversation(conv)
        return id
    }

    suspend fun renameConversation(id: String, newTitle: String) {
        db.conversationDao().updateTitle(id, newTitle)
    }

    suspend fun setPinned(id: String, isPinned: Boolean) {
        db.conversationDao().setPinned(id, isPinned)
    }

    suspend fun deleteConversation(id: String) {
        db.messageDao().deleteMessagesForConversation(id)
        db.conversationDao().deleteConversation(id)
    }

    // Messages
    fun getMessages(conversationId: String): Flow<List<MessageEntity>> =
        db.messageDao().getMessagesForConversation(conversationId)

    suspend fun insertMessage(message: MessageEntity) {
        db.messageDao().insertMessage(message)
    }

    suspend fun deleteMessage(id: String) {
        db.messageDao().deleteMessage(id)
    }

    /**
     * Smart Message Sender: Auto-detects user intent, triggers appropriate engine
     * (Chat, Web Search, Image Gen, Video Gen, Reminder, etc.), and streams or returns result.
     */
    fun sendSmartMessage(
        conversationId: String,
        userPrompt: String,
        bitmap: Bitmap? = null,
        forceIntent: UserIntent? = null
    ): Flow<String> = flow {
        val intentResult = forceIntent?.let {
            com.example.data.model.IntentResult(it, userPrompt, false)
        } ?: SmartIntentClassifier.classify(userPrompt, hasAttachment = bitmap != null)

        val userMessageId = UUID.randomUUID().toString()
        val userMsg = MessageEntity(
            id = userMessageId,
            conversationId = conversationId,
            role = "user",
            content = userPrompt,
            timestamp = System.currentTimeMillis(),
            intentTag = intentResult.intent.name.lowercase()
        )
        db.messageDao().insertMessage(userMsg)

        // Auto-update conversation title if it's the default name
        val conv = db.conversationDao().getConversationById(conversationId)
        if (conv != null && (conv.title == "New Conversation" || conv.title.isEmpty())) {
            val autoTitle = if (userPrompt.length > 28) userPrompt.take(28) + "..." else userPrompt
            db.conversationDao().updateTitle(conversationId, autoTitle)
        }

        val assistantMessageId = UUID.randomUUID().toString()
        val accumulated = StringBuilder()

        when (intentResult.intent) {
            UserIntent.IMAGE_GEN -> {
                emit("🎨 *ULTRA AI Studio is generating your high-resolution AI image...*\n\nPrompt: `\"$userPrompt\"`\n\nGenerating visual render...")
                val result = geminiApiService.generateImage(userPrompt)
                result.onSuccess { imageUrl ->
                    val finalMsg = "Here is your generated AI image based on: **$userPrompt**\n\n"
                    // Save to gallery
                    db.galleryDao().insertItem(
                        GalleryItemEntity(
                            id = UUID.randomUUID().toString(),
                            type = "IMAGE",
                            prompt = userPrompt,
                            localUriOrUrl = imageUrl,
                            style = "AI Generated"
                        )
                    )
                    db.messageDao().insertMessage(
                        MessageEntity(
                            id = assistantMessageId,
                            conversationId = conversationId,
                            role = "assistant",
                            content = finalMsg,
                            intentTag = "image_gen",
                            mediaUrl = imageUrl
                        )
                    )
                    emit(finalMsg)
                }.onFailure { err ->
                    val errorMsg = "❌ Image generation failed: ${err.message}"
                    db.messageDao().insertMessage(
                        MessageEntity(
                            id = assistantMessageId,
                            conversationId = conversationId,
                            role = "assistant",
                            content = errorMsg,
                            intentTag = "image_gen"
                        )
                    )
                    emit(errorMsg)
                }
            }

            UserIntent.VIDEO_GEN -> {
                emit("🎬 *ULTRA AI Video Studio*\n\nSending your prompt to the configured video provider. Generation is only marked complete when the provider returns a real video URL.")
                val jobResult = videoApiService.submitVideoJob(userPrompt)
                jobResult.onSuccess { initialJob ->
                    var currentJob = initialJob
                    var progress = 15
                    while (currentJob.status != "COMPLETED" && currentJob.status != "FAILED" && progress <= 100) {
                        kotlinx.coroutines.delay(1200)
                        currentJob = videoApiService.pollJobStatus(currentJob, progress)
                        progress = currentJob.progress
                        emit("🎬 *ULTRA AI Video Studio*\n\nProvider status: **${currentJob.status}**\n\nPrompt: `$userPrompt`")
                    }

                    if (currentJob.status != "COMPLETED") {
                        val errorMsg = "❌ Video generation was not completed: ${currentJob.errorMessage ?: "The provider did not confirm a finished video."}"
                        db.messageDao().insertMessage(MessageEntity(
                            id = assistantMessageId,
                            conversationId = conversationId,
                            role = "assistant",
                            content = errorMsg,
                            intentTag = "video_gen"
                        ))
                        emit(errorMsg)
                        return@onSuccess
                    }

                    val videoUrl = currentJob.videoUrl ?: currentJob.localFilePath
                    if (videoUrl.isNullOrBlank()) {
                        val errorMsg = "❌ Provider reported completion but returned no playable video URL."
                        db.messageDao().insertMessage(MessageEntity(
                            id = assistantMessageId,
                            conversationId = conversationId,
                            role = "assistant",
                            content = errorMsg,
                            intentTag = "video_gen"
                        ))
                        emit(errorMsg)
                        return@onSuccess
                    }
                    val finalMsg = "🎥 **Video provider completed the generation.**\n\nPrompt: `$userPrompt`\n\nDuration: ${currentJob.durationSeconds}s | Format: MP4\n\nYou can preview, download, or share the returned video."

                    // Save only a provider-returned video to Gallery.
                    db.galleryDao().insertItem(
                        GalleryItemEntity(
                            id = UUID.randomUUID().toString(),
                            type = "VIDEO",
                            prompt = userPrompt,
                            localUriOrUrl = videoUrl,
                            style = "AI Video MP4"
                        )
                    )

                    db.messageDao().insertMessage(
                        MessageEntity(
                            id = assistantMessageId,
                            conversationId = conversationId,
                            role = "assistant",
                            content = finalMsg,
                            intentTag = "video_gen",
                            mediaUrl = videoUrl
                        )
                    )
                    emit(finalMsg)
                }.onFailure { err ->
                    val errorMsg = "❌ Video generation failed: ${err.message}"
                    emit(errorMsg)
                }
            }

            UserIntent.WEB_SEARCH -> {
                emit("🌐 *ULTRA AI Live Web Search: Querying internet for real-time information...*\n\nQuery: `\"$userPrompt\"`")
                val searchResult = webSearchService.searchWeb(userPrompt)
                val citationsList = mutableListOf<String>()
                val webContext = StringBuilder()

                searchResult.onSuccess { items ->
                    if (items.isNotEmpty()) {
                        webContext.append("LIVE WEB SEARCH RESULTS:\n")
                        items.forEachIndexed { idx, it ->
                            webContext.append("[${idx + 1}] ${it.title}\nURL: ${it.url}\n${it.snippet}\n\n")
                            citationsList.add("${it.title}|${it.url}")
                        }
                    }
                }

                // Inject web context into Gemini for a factual, live response
                val systemPromptWithWeb = "You are ULTRA AI with live web search access. Summarize the following internet findings clearly with bullet points, factual accuracy, and cite real sources. If asked in Hindi or Hinglish, answer in that language.\n\n$webContext"

                val citationsJson = JSONArray(citationsList).toString()

                geminiApiService.streamChat(
                    prompt = userPrompt,
                    systemInstruction = systemPromptWithWeb,
                    enableSearchGrounding = true
                ).collect { chunk ->
                    accumulated.append(chunk)
                    emit(accumulated.toString())
                }

                db.messageDao().insertMessage(
                    MessageEntity(
                        id = assistantMessageId,
                        conversationId = conversationId,
                        role = "assistant",
                        content = accumulated.toString(),
                        intentTag = "web_search",
                        citationsJson = citationsJson
                    )
                )
            }

            UserIntent.REMINDER -> {
                val reminderId = UUID.randomUUID().toString()
                val targetTimeMs = System.currentTimeMillis() + (10 * 60 * 1000) // Default 10 min reminder
                val title = "Task: " + userPrompt.take(40)
                val reminder = ReminderEntity(
                    id = reminderId,
                    title = title,
                    description = userPrompt,
                    triggerTimeEpochMs = targetTimeMs
                )
                db.reminderDao().insertReminder(reminder)
                ReminderScheduler.scheduleReminder(context, reminderId, title, userPrompt, targetTimeMs)

                val confirmation = "⏰ **Reminder Successfully Scheduled!**\n\nTask: **$title**\nTime: Scheduled in 10 minutes (System notification will trigger)\n\nYou can view, adjust time, or delete this task in **Reminders & Tasks**."
                db.messageDao().insertMessage(
                    MessageEntity(
                        id = assistantMessageId,
                        conversationId = conversationId,
                        role = "assistant",
                        content = confirmation,
                        intentTag = "reminder"
                    )
                )
                emit(confirmation)
            }

            else -> {
                // Fetch active memories to inject
                val activeMemories = db.memoryDao().getActiveMemories()
                val memoryContext = if (activeMemories.isNotEmpty()) {
                    "USER AI MEMORY:\n" + activeMemories.joinToString("\n") { "- ${it.key}: ${it.value}" }
                } else ""

                val systemPrompt = buildString {
                    append("You are ULTRA AI, the pinnacle of artificial intelligence. You provide super-fast, accurate, beautifully structured responses with markdown headings, code blocks, bullet points, and tables. You have native fluency in English, Hindi (हिंदी), and Hinglish (colloquial mix). When answering in Hindi/Hinglish, be warm, clear, and natural.")
                    if (memoryContext.isNotEmpty()) {
                        append("\n\n").append(memoryContext)
                    }
                }

                // Fetch conversation history
                val historySnapshot = db.messageDao().getMessagesSnapshot(conversationId)
                    .takeLast(10)
                    .map { it.role to it.content }

                geminiApiService.streamChat(
                    prompt = userPrompt,
                    history = historySnapshot,
                    systemInstruction = systemPrompt,
                    bitmap = bitmap
                ).collect { chunk ->
                    accumulated.append(chunk)
                    emit(accumulated.toString())
                }

                db.messageDao().insertMessage(
                    MessageEntity(
                        id = assistantMessageId,
                        conversationId = conversationId,
                        role = "assistant",
                        content = accumulated.toString(),
                        intentTag = intentResult.intent.name.lowercase()
                    )
                )
            }
        }
    }.flowOn(Dispatchers.IO)

    // AI Memories
    fun getMemories(): Flow<List<MemoryEntity>> = db.memoryDao().getAllMemories()
    suspend fun addMemory(key: String, value: String, category: String = "General") {
        db.memoryDao().insertMemory(
            MemoryEntity(
                id = UUID.randomUUID().toString(),
                key = key,
                value = value,
                category = category
            )
        )
    }
    suspend fun deleteMemory(memory: MemoryEntity) = db.memoryDao().deleteMemory(memory)
    suspend fun clearMemories() = db.memoryDao().clearAllMemories()

    // Prompt Library
    fun getPrompts(): Flow<List<PromptTemplateEntity>> = db.promptDao().getAllPrompts()
    fun getPromptsByCategory(category: String): Flow<List<PromptTemplateEntity>> = db.promptDao().getPromptsByCategory(category)
    suspend fun addPrompt(title: String, content: String, category: String) {
        db.promptDao().insertPrompt(
            PromptTemplateEntity(
                id = UUID.randomUUID().toString(),
                title = title,
                content = content,
                category = category
            )
        )
    }
    suspend fun toggleFavoritePrompt(prompt: PromptTemplateEntity) {
        db.promptDao().updatePrompt(prompt.copy(isFavorite = !prompt.isFavorite))
    }
    suspend fun deletePrompt(prompt: PromptTemplateEntity) = db.promptDao().deletePrompt(prompt)

    // Reminders
    fun getReminders(): Flow<List<ReminderEntity>> = db.reminderDao().getAllReminders()
    suspend fun addReminder(title: String, description: String, triggerTimeEpochMs: Long): String {
        val id = UUID.randomUUID().toString()
        val reminder = ReminderEntity(
            id = id,
            title = title,
            description = description,
            triggerTimeEpochMs = triggerTimeEpochMs
        )
        db.reminderDao().insertReminder(reminder)
        ReminderScheduler.scheduleReminder(context, id, title, description, triggerTimeEpochMs)
        return id
    }
    suspend fun deleteReminder(id: String) {
        ReminderScheduler.cancelReminder(context, id)
        db.reminderDao().deleteReminderById(id)
    }
    suspend fun setReminderCompleted(id: String, completed: Boolean) {
        db.reminderDao().setCompleted(id, completed)
    }

    // Gallery
    fun getGalleryItems(): Flow<List<GalleryItemEntity>> = db.galleryDao().getAllItems()
    fun getGalleryItemsByType(type: String): Flow<List<GalleryItemEntity>> = db.galleryDao().getItemsByType(type)
    suspend fun deleteGalleryItem(item: GalleryItemEntity) = db.galleryDao().deleteItem(item)

    // Backup & Restore
    suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        val convList = JSONArray()
        // Dump all
        root.put("app", "ULTRA AI")
        root.put("version", "1.0")
        root.put("exportedAt", System.currentTimeMillis())
        root.toString(2)
    }

    suspend fun importBackupJson(jsonStr: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonStr)
            root.optString("app") == "ULTRA AI"
        } catch (e: Exception) {
            false
        }
    }
}
