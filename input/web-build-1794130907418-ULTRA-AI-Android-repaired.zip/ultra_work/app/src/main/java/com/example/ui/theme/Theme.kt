package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val UltraDarkColorScheme = darkColorScheme(
    primary = UltraCyan,
    onPrimary = UltraDarkBg,
    primaryContainer = UltraCyan.copy(alpha = 0.2f),
    onPrimaryContainer = UltraCyan,
    secondary = UltraPurple,
    onSecondary = TextPrimary,
    secondaryContainer = UltraPurple.copy(alpha = 0.25f),
    onSecondaryContainer = UltraPurple,
    tertiary = UltraNeonPink,
    onTertiary = TextPrimary,
    background = UltraDarkBg,
    onBackground = TextPrimary,
    surface = UltraSurface,
    onSurface = TextPrimary,
    surfaceVariant = UltraSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = UltraCardBorder,
    error = UltraRose,
    onError = TextPrimary
)

private val UltraLightColorScheme = lightColorScheme(
    primary = UltraElectricBlue,
    onPrimary = TextPrimary,
    primaryContainer = UltraElectricBlue.copy(alpha = 0.15f),
    onPrimaryContainer = UltraElectricBlue,
    secondary = UltraPurple,
    onSecondary = TextPrimary,
    background = UltraLightBg,
    onBackground = UltraDarkBg,
    surface = UltraLightSurface,
    onSurface = UltraDarkBg,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = TextMuted,
    outline = UltraLightCardBorder,
    error = UltraRose,
    onError = TextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our signature cyber aesthetic for consistent ULTRA AI branding
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) UltraDarkColorScheme else UltraDarkColorScheme // Default to signature dark cyber UI

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
