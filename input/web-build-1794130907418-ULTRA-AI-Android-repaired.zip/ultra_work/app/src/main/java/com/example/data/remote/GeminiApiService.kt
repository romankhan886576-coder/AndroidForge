package com.example.data.remote

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class GeminiApiService(
    private val customApiKey: String? = null
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun getEffectiveApiKey(): String {
        val configured = customApiKey?.trim()
        if (!configured.isNullOrEmpty()) return configured
        return try {
            val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
            (field.get(null) as? String)?.trim().orEmpty()
        } catch (e: Throwable) {
            ""
        }
    }

    /**
     * Fast streaming response for text & multimodal queries
     */
    fun streamChat(
        prompt: String,
        history: List<Pair<String, String>> = emptyList(), // role to content
        systemInstruction: String = "You are ULTRA AI, the ultimate world-class AI intelligence engine. You respond rapidly with crystal-clear formatting, code blocks, lists, and deep insights. Support Hindi, English, and Hinglish natively.",
        bitmap: Bitmap? = null,
        enableSearchGrounding: Boolean = false,
        modelName: String = "gemini-2.0-flash"
    ): Flow<String> = flow {
        val apiKey = getEffectiveApiKey()
        if (apiKey.isEmpty()) {
            emit("⚠️ **ULTRA AI Notice**: Gemini API Key is not configured yet.\n\nPlease add your `GEMINI_API_KEY` in the AI Studio **Secrets Panel** or go to **ULTRA AI Settings / Owner Dashboard** to enter your API key directly.")
            return@flow
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:streamGenerateContent?alt=sse&key=$apiKey"

        val contentsArray = JSONArray()

        // Append conversation history
        for ((role, text) in history) {
            val contentObj = JSONObject()
            contentObj.put("role", if (role.equals("user", true)) "user" else "model")
            val parts = JSONArray()
            val textPart = JSONObject().put("text", text)
            parts.put(textPart)
            contentObj.put("parts", parts)
            contentsArray.put(contentObj)
        }

        // Current user message
        val currentContentObj = JSONObject().put("role", "user")
        val currentParts = JSONArray()

        if (bitmap != null) {
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

            val imagePart = JSONObject().put("inlineData", JSONObject().apply {
                put("mimeType", "image/jpeg")
                put("data", base64Image)
            })
            currentParts.put(imagePart)
        }

        currentParts.put(JSONObject().put("text", prompt))
        currentContentObj.put("parts", currentParts)
        contentsArray.put(currentContentObj)

        val rootJson = JSONObject().apply {
            put("contents", contentsArray)
            if (systemInstruction.isNotEmpty()) {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
                })
            }
            if (enableSearchGrounding) {
                put("tools", JSONArray().put(JSONObject().apply {
                    put("googleSearch", JSONObject())
                }))
            }
        }

        val request = Request.Builder()
            .url(url)
            .post(rootJson.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string().orEmpty()
                    val errorMsg = try {
                        val errObj = JSONObject(errBody)
                        errObj.optJSONObject("error")?.optString("message") ?: "HTTP ${response.code}"
                    } catch (e: Exception) {
                        "HTTP ${response.code}: $errBody"
                    }
                    emit("❌ **ULTRA AI Provider Error**: $errorMsg\n\n(Code: ${response.code})")
                    return@flow
                }

                val reader = BufferedReader(InputStreamReader(response.body!!.byteStream()))
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val currentLine = line ?: continue
                    if (currentLine.startsWith("data: ")) {
                        val jsonStr = currentLine.substring(6).trim()
                        if (jsonStr.isNotEmpty() && jsonStr != "[DONE]") {
                            try {
                                val chunkObj = JSONObject(jsonStr)
                                val candidates = chunkObj.optJSONArray("candidates")
                                if (candidates != null && candidates.length() > 0) {
                                    val candidate = candidates.getJSONObject(0)
                                    val content = candidate.optJSONObject("content")
                                    val parts = content?.optJSONArray("parts")
                                    if (parts != null) {
                                        for (i in 0 until parts.length()) {
                                            val part = parts.getJSONObject(i)
                                            val text = part.optString("text")
                                            if (text.isNotEmpty()) {
                                                emit(text)
                                            }
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                Log.e("GeminiApiService", "Parse error: ${e.message}")
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            emit("\n\n⚠️ **Network Connection Failed**: ${e.localizedMessage ?: "Unable to reach AI provider"}. Please check your internet connectivity.")
        }
    }.flowOn(Dispatchers.IO)

    /**
     * Real AI Image Generation
     */
    suspend fun generateImage(
        prompt: String,
        aspectRatio: String = "1:1"
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey()
        if (apiKey.isEmpty()) {
            return@withContext Result.failure(Exception("Gemini API Key is missing. Configure in Settings or AI Studio Secrets."))
        }

        // Try Imagen 3 API endpoint
        val url = "https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict?key=$apiKey"
        val payload = JSONObject().apply {
            val instances = JSONArray().put(JSONObject().apply {
                put("prompt", prompt)
            })
            put("instances", instances)
            put("parameters", JSONObject().apply {
                put("sampleCount", 1)
                put("aspectRatio", aspectRatio)
            })
        }

        try {
            val request = Request.Builder()
                .url(url)
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val resJson = JSONObject(bodyStr)
                    val predictions = resJson.optJSONArray("predictions")
                    if (predictions != null && predictions.length() > 0) {
                        val b64 = predictions.getJSONObject(0).optString("bytesBase64Encoded")
                        if (b64.isNotEmpty()) {
                            return@withContext Result.success("data:image/jpeg;base64,$b64")
                        }
                    }
                }
                // If Imagen fails or is unprovisioned on key, fall back gracefully to Pollinations / HuggingFace real AI render
                val encodedPrompt = java.net.URLEncoder.encode(prompt, "UTF-8")
                val realAiImageUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=1024&height=1024&nologo=true&model=flux"
                Result.success(realAiImageUrl)
            }
        } catch (e: Exception) {
            // Real AI online fallback endpoint
            val encodedPrompt = java.net.URLEncoder.encode(prompt, "UTF-8")
            val realAiImageUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=1024&height=1024&nologo=true&model=flux"
            Result.success(realAiImageUrl)
        }
    }
}
