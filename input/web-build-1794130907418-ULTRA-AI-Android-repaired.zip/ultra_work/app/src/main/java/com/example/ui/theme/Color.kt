package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Cybernetic Neon Palette for ULTRA AI
val UltraDarkBg = Color(0xFF090D16)
val UltraSurface = Color(0xFF101726)
val UltraSurfaceVariant = Color(0xFF172238)
val UltraCardBorder = Color(0xFF1F2E4A)

// Vibrant Cyber Accents
val UltraCyan = Color(0xFF00E5FF)
val UltraCyanGlow = Color(0xFF38EFFF)
val UltraPurple = Color(0xFF8B5CF6)
val UltraNeonPink = Color(0xFFFF2E93)
val UltraElectricBlue = Color(0xFF2563EB)
val UltraEmerald = Color(0xFF10B981)
val UltraAmber = Color(0xFFF59E0B)
val UltraRose = Color(0xFFF43F5E)

// Text & Surfaces
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Light Mode Fallback
val UltraLightBg = Color(0xFFF8FAFC)
val UltraLightSurface = Color(0xFFFFFFFF)
val UltraLightCardBorder = Color(0xFFE2E8F0)
