package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val modelId: String = "gemini-2.0-flash",
    val systemPrompt: String = ""
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String, // "user", "assistant", "system"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val intentTag: String = "chat", // "chat", "image_gen", "video_gen", "web_search", "code", "story", "file_analysis", "translation", "reminder"
    val mediaUrl: String? = null,
    val citationsJson: String? = null
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val key: String,
    val value: String,
    val category: String = "General",
    val createdAt: Long = System.currentTimeMillis(),
    val isEnabled: Boolean = true
)

@Entity(tableName = "prompt_templates")
data class PromptTemplateEntity(
    @PrimaryKey val id: String,
    val title: String,
    val content: String,
    val category: String, // "Coding", "Stories", "Social & Scripts", "Business", "Image Gen", "Hindi/Hinglish"
    val isFavorite: Boolean = false,
    val isBuiltIn: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String = "",
    val triggerTimeEpochMs: Long,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "gallery_items")
data class GalleryItemEntity(
    @PrimaryKey val id: String,
    val type: String, // "IMAGE", "VIDEO", "DOCUMENT"
    val prompt: String,
    val localUriOrUrl: String,
    val style: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "invite_codes")
data class InviteCodeEntity(
    @PrimaryKey val code: String,
    val createdBy: String = "romankhan886576@gmail.com",
    val assignedToEmail: String = "",
    val status: String = "ACTIVE", // "ACTIVE", "USED", "REVOKED", "SUSPENDED"
    val role: String = "INVITED_USER", // "OWNER", "INVITED_USER"
    val createdAt: Long = System.currentTimeMillis(),
    val canUseChat: Boolean = true,
    val canUseImageGen: Boolean = true,
    val canUseVideoGen: Boolean = true,
    val canUseWebSearch: Boolean = true,
    val canUseFiles: Boolean = true
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val action: String,
    val actor: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val email: String,
    val displayName: String,
    val role: String, // "OWNER", "INVITED_USER"
    val status: String, // "ACTIVE", "REVOKED", "SUSPENDED"
    val pinHash: String = "",
    val activeSessionToken: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastLoginAt: Long = System.currentTimeMillis()
)
