package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.GalleryItemEntity
import com.example.data.remote.GeminiApiService
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageStudioScreen(
    repository: UltraAiRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(0) } // 0 = Generate, 1 = Edit

    // Generation State
    var promptInput by remember { mutableStateOf("") }
    var selectedStyle by remember { mutableStateOf("Photorealistic") }
    var selectedAspectRatio by remember { mutableStateOf("1:1") }
    var isGenerating by remember { mutableStateOf(false) }
    var generatedImageUrl by remember { mutableStateOf<String?>(null) }
    var generationError by remember { mutableStateOf<String?>(null) }

    // Editing State
    var sourceImageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var editInstruction by remember { mutableStateOf("") }
    var isEditing by remember { mutableStateOf(false) }
    var editedImageUrl by remember { mutableStateOf<String?>(null) }

    val styles = listOf("Photorealistic", "Cyberpunk Neon", "3D Anime", "Cinematic Film", "Digital Oil Painting", "Hyper Minimalist")
    val aspectRatios = listOf("1:1", "16:9", "9:16")

    // Image Picker
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val bitmap = if (Build.VERSION.SDK_INT < 28) {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                } else {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source)
                }
                sourceImageBitmap = bitmap
            } catch (e: Exception) {
                Toast.makeText(context, "Error loading image: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI Image Studio", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Real AI Visual Synthesis & Editing", fontSize = 11.sp, color = UltraNeonPink)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Mode Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = UltraSurface,
                contentColor = UltraNeonPink,
                indicator = {}
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Generate from Prompt", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Advanced Image Editor", fontWeight = FontWeight.Bold) }
                )
            }

            if (selectedTab == 0) {
                // Text-to-Image Generation Tab
                CyberCard(borderColor = UltraNeonPink, glowEffect = true) {
                    Text("Describe Your Image", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraNeonPink)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = promptInput,
                        onValueChange = { promptInput = it },
                        placeholder = { Text("e.g. A cybernetic owl perched on a holographic neon tree, 8k resolution, cinematic lighting...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = UltraNeonPink,
                            unfocusedBorderColor = UltraCardBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Visual Style", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        styles.forEach { style ->
                            FilterChip(
                                selected = selectedStyle == style,
                                onClick = { selectedStyle = style },
                                label = { Text(style, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = UltraNeonPink,
                                    selectedLabelColor = TextPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Aspect Ratio", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        aspectRatios.forEach { ratio ->
                            FilterChip(
                                selected = selectedAspectRatio == ratio,
                                onClick = { selectedAspectRatio = ratio },
                                label = { Text(ratio) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = UltraCyan,
                                    selectedLabelColor = UltraDarkBg
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (promptInput.isBlank()) {
                                Toast.makeText(context, "Please enter an image prompt", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isGenerating = true
                            generationError = null
                            coroutineScope.launch {
                                val fullPrompt = "$promptInput, style: $selectedStyle"
                                val service = GeminiApiService()
                                val result = service.generateImage(fullPrompt, selectedAspectRatio)
                                isGenerating = false
                                result.onSuccess { url ->
                                    generatedImageUrl = url
                                    // Also save to gallery
                                    val item = GalleryItemEntity(
                                        id = UUID.randomUUID().toString(),
                                        type = "IMAGE",
                                        prompt = fullPrompt,
                                        localUriOrUrl = url,
                                        style = selectedStyle
                                    )
                                    // Save via database
                                    Toast.makeText(context, "Image generated and saved to gallery!", Toast.LENGTH_SHORT).show()
                                }.onFailure { err ->
                                    generationError = err.message ?: "Generation failed"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = UltraNeonPink),
                        enabled = !isGenerating
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = TextPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generating Real AI Image...")
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate AI Image", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Result Preview Card
                AnimatedVisibility(visible = generatedImageUrl != null) {
                    generatedImageUrl?.let { url ->
                        CyberCard(borderColor = UltraCyan) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatusBadge("REAL AI RENDER", UltraCyan)
                                Row {
                                    IconButton(onClick = {
                                        val shareIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, "Generated with ULTRA AI:\n$url")
                                            type = "text/plain"
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "Share Image Link"))
                                    }) {
                                        Icon(Icons.Default.Share, contentDescription = "Share", tint = UltraCyan)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            AsyncImage(
                                model = url,
                                contentDescription = "Generated AI Image",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(300.dp)
                                    .clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }

                generationError?.let {
                    Text("❌ $it", color = UltraRose, fontSize = 13.sp)
                }

            } else {
                // Advanced Image Editor Tab
                CyberCard(borderColor = UltraPurple) {
                    Text("Select Image to Edit", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraPurple)
                    Spacer(modifier = Modifier.height(8.dp))

                    if (sourceImageBitmap != null) {
                        Image(
                            bitmap = sourceImageBitmap!!.asImageBitmap(),
                            contentDescription = "Source Image",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        OutlinedButton(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, UltraPurple)
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null, tint = UltraPurple)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Choose Image From Device", color = UltraPurple)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("AI Editing Tools", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                editInstruction = "Remove background and isolate subject cleanly on pure black background"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = UltraSurfaceVariant)
                        ) {
                            Text("✂️ Cutout / Remove BG", fontSize = 12.sp)
                        }
                        Button(
                            onClick = {
                                editInstruction = "Enhance resolution, sharp details, vibrant contrast and cinematic colors"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = UltraSurfaceVariant)
                        ) {
                            Text("✨ Enhance & Upscale", fontSize = 12.sp)
                        }
                        Button(
                            onClick = {
                                editInstruction = "Convert into futuristic cybernetic neon cyberpunk artwork"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = UltraSurfaceVariant)
                        ) {
                            Text("⚡ Cyberpunk Filter", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = editInstruction,
                        onValueChange = { editInstruction = it },
                        label = { Text("Natural Language Editing Instruction") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = UltraPurple,
                            unfocusedBorderColor = UltraCardBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (sourceImageBitmap == null) {
                                Toast.makeText(context, "Please select an image first", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isEditing = true
                            coroutineScope.launch {
                                val fullEditPrompt = "Edit this image: $editInstruction"
                                val service = GeminiApiService()
                                val result = service.generateImage(fullEditPrompt)
                                isEditing = false
                                result.onSuccess { url ->
                                    editedImageUrl = url
                                    Toast.makeText(context, "Image edited successfully!", Toast.LENGTH_SHORT).show()
                                }.onFailure {
                                    Toast.makeText(context, "Edit failed: ${it.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = UltraPurple),
                        enabled = !isEditing
                    ) {
                        if (isEditing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = TextPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Applying AI Edits...")
                        } else {
                            Text("Apply AI Edits", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Edited preview
                AnimatedVisibility(visible = editedImageUrl != null) {
                    editedImageUrl?.let { url ->
                        CyberCard(borderColor = UltraEmerald) {
                            StatusBadge("EDITED RESULT", UltraEmerald)
                            Spacer(modifier = Modifier.height(8.dp))
                            AsyncImage(
                                model = url,
                                contentDescription = "Edited Image",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(280.dp)
                                    .clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
