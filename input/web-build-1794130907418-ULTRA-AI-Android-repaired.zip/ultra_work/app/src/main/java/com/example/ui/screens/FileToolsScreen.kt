package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.FormattedMarkdownText
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileToolsScreen(
    repository: UltraAiRepository,
    onBack: () -> Unit,
    onOpenChatWithContent: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedFileName by remember { mutableStateOf<String?>(null) }
    var fileContent by remember { mutableStateOf("") }
    var fileStats by remember { mutableStateOf("") }
    var isAnalyzing by remember { mutableStateOf(false) }
    var analysisResult by remember { mutableStateOf<String?>(null) }

    // Document Generator states
    var docTitle by remember { mutableStateOf("") }
    var docPrompt by remember { mutableStateOf("") }
    var isGeneratingDoc by remember { mutableStateOf(false) }
    var generatedDocText by remember { mutableStateOf<String?>(null) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val contentResolver = context.contentResolver
                    val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "Document"
                    selectedFileName = fileName

                    val stringBuilder = StringBuilder()
                    withContext(Dispatchers.IO) {
                        contentResolver.openInputStream(uri)?.use { stream ->
                            BufferedReader(InputStreamReader(stream)).use { reader ->
                                var line: String?
                                var count = 0
                                while (reader.readLine().also { line = it } != null && count < 500) {
                                    stringBuilder.append(line).append("\n")
                                    count++
                                }
                            }
                        }
                    }

                    fileContent = stringBuilder.toString()
                    val wordCount = fileContent.split("\\s+".toRegex()).count { it.isNotBlank() }
                    fileStats = "${fileContent.length} characters • ~$wordCount words"
                } catch (e: Exception) {
                    Toast.makeText(context, "Failed to read file: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("File Tools & Doc Studio", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Document Reading, Analytics & AI Generation", fontSize = 11.sp, color = UltraElectricBlue)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Upload & Analyze Card
            CyberCard(borderColor = UltraElectricBlue, glowEffect = true) {
                Text("Analyze Document (PDF, TXT, CSV, DOCX)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraElectricBlue)
                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { filePickerLauncher.launch("*/*") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = UltraSurfaceVariant)
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, tint = UltraElectricBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (selectedFileName == null) "Choose File From Storage" else "Selected: $selectedFileName")
                }

                if (selectedFileName != null && fileContent.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusBadge("READY FOR ANALYSIS", UltraEmerald)
                        Text(fileStats, fontSize = 11.sp, color = TextMuted)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = fileContent.take(300) + if (fileContent.length > 300) "..." else "",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(UltraDarkBg)
                            .padding(10.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                isAnalyzing = true
                                coroutineScope.launch {
                                    val convId = repository.createConversation("Analysis: $selectedFileName")
                                    val prompt = "Please thoroughly analyze this uploaded document, extract key bullet points, and provide an executive summary:\n\n$fileContent"
                                    val acc = StringBuilder()
                                    repository.sendSmartMessage(convId, prompt).collect { chunk ->
                                        acc.clear()
                                        acc.append(chunk)
                                        analysisResult = chunk
                                    }
                                    isAnalyzing = false
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = UltraElectricBlue),
                            enabled = !isAnalyzing
                        ) {
                            Text("Summarize Document", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                onOpenChatWithContent("Analyze this document:\n\n$fileContent")
                            },
                            modifier = Modifier.weight(1f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, UltraCyan)
                        ) {
                            Text("Open in Chat", color = UltraCyan, fontSize = 12.sp)
                        }
                    }
                }

                AnimatedVisibility(visible = isAnalyzing) {
                    Row(
                        modifier = Modifier.padding(top = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = UltraElectricBlue)
                        Text("Extracting key insights with ULTRA AI...", fontSize = 12.sp, color = TextSecondary)
                    }
                }

                AnimatedVisibility(visible = analysisResult != null) {
                    analysisResult?.let {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            FormattedMarkdownText(text = it)
                        }
                    }
                }
            }

            // Document Creation & Export Studio
            CyberCard(borderColor = UltraCyan) {
                Text("AI Document Creator", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = UltraCyan)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = docTitle,
                    onValueChange = { docTitle = it },
                    label = { Text("Document Title") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = UltraCyan,
                        unfocusedBorderColor = UltraCardBorder
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = docPrompt,
                    onValueChange = { docPrompt = it },
                    placeholder = { Text("e.g. Write a comprehensive Project Requirements Document (PRD) for an AI platform...") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = UltraCyan,
                        unfocusedBorderColor = UltraCardBorder
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (docPrompt.isBlank()) return@Button
                        isGeneratingDoc = true
                        coroutineScope.launch {
                            val convId = repository.createConversation("Doc: ${docTitle.ifEmpty { "Generated Doc" }}")
                            val acc = StringBuilder()
                            repository.sendSmartMessage(convId, "Generate a complete, formal, beautifully structured document for: $docTitle\n\nRequirements: $docPrompt").collect {
                                acc.clear()
                                acc.append(it)
                                generatedDocText = it
                            }
                            isGeneratingDoc = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = UltraCyan),
                    enabled = !isGeneratingDoc
                ) {
                    Text("Generate Formal Document", color = UltraDarkBg, fontWeight = FontWeight.Bold)
                }

                AnimatedVisibility(visible = generatedDocText != null) {
                    generatedDocText?.let { text ->
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatusBadge("DOCUMENT EXPORT READY", UltraCyan)
                                IconButton(onClick = {
                                    val sendIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(Intent.EXTRA_TITLE, docTitle)
                                        putExtra(Intent.EXTRA_TEXT, text)
                                        type = "text/plain"
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, "Export Document"))
                                }) {
                                    Icon(Icons.Default.Share, contentDescription = "Export", tint = UltraCyan)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            FormattedMarkdownText(text = text)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
