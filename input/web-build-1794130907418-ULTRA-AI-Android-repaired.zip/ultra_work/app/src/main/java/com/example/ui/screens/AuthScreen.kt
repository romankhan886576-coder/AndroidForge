package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.repository.AuthRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.PulsingAiOrb
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    authRepo: AuthRepository,
    onAuthenticated: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var isOwnerTab by remember { mutableStateOf(true) }
    val ownerConfigured = remember { authRepo.isOwnerConfigured() }
    var ownerEmail by remember { mutableStateOf("romankhan886576@gmail.com") }
    var ownerPin by remember { mutableStateOf("") }

    var inviteCode by remember { mutableStateOf("") }
    var userName by remember { mutableStateOf("") }
    var userEmail by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(UltraDarkBg)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            // Glowing AI Core Logo
            Box(contentAlignment = Alignment.Center) {
                PulsingAiOrb(size = 90.dp)
                Image(
                    painter = painterResource(id = R.drawable.ic_ultra_ai_logo),
                    contentDescription = "ULTRA AI Logo",
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
            }

            Text(
                text = "ULTRA AI",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary,
                letterSpacing = 2.sp
            )

            Text(
                text = "Secure Private Access & Owner Control System",
                fontSize = 13.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            // Tab Selector: Owner / Invitation
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(UltraSurfaceVariant)
                    .padding(4.dp)
            ) {
                FilterChip(
                    selected = isOwnerTab,
                    onClick = {
                        isOwnerTab = true
                        errorMessage = null
                    },
                    label = { Text("Super Admin / Owner") },
                    leadingIcon = { Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = UltraCyan,
                        selectedLabelColor = UltraDarkBg
                    )
                )
                Spacer(modifier = Modifier.width(6.dp))
                FilterChip(
                    selected = !isOwnerTab,
                    onClick = {
                        isOwnerTab = false
                        errorMessage = null
                    },
                    label = { Text("Invited Access") },
                    leadingIcon = { Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = UltraPurple,
                        selectedLabelColor = TextPrimary
                    )
                )
            }

            CyberCard(
                borderColor = if (isOwnerTab) UltraCyan else UltraPurple,
                glowEffect = true
            ) {
                if (isOwnerTab) {
                    Text(
                        text = if (ownerConfigured) "Owner Super Admin Sign In" else "Create Owner Account",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = UltraCyan
                    )
                    Text(
                        text = if (ownerConfigured) "Authorized Owner: $ownerEmail\nEnter your master security PIN to access the full system." else "First-time setup: choose a private owner PIN. Only you should know this PIN.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = ownerPin,
                        onValueChange = { ownerPin = it },
                        label = { Text(if (ownerConfigured) "Master PIN" else "Create Master PIN (minimum 4 digits)") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = UltraCyan) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = UltraCyan,
                            unfocusedBorderColor = UltraCardBorder
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (ownerPin.length < 4) {
                                errorMessage = "PIN must be at least 4 digits."
                                return@Button
                            }
                            isLoading = true
                            errorMessage = null
                            coroutineScope.launch {
                                // First use creates the owner credential; later uses only verify it.
                                if (!ownerConfigured) authRepo.setupOwner(ownerEmail, ownerPin)
                                val success = authRepo.loginOwner(ownerPin)
                                isLoading = false
                                if (success) {
                                    onAuthenticated()
                                } else {
                                    errorMessage = "Invalid Master PIN. Please try again."
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = UltraCyan)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = UltraDarkBg)
                        } else {
                            Text(if (ownerConfigured) "Unlock ULTRA AI" else "Create Owner Account", color = UltraDarkBg, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    // Invited User Tab
                    Text(
                        text = "Invited User Passcode",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = UltraPurple
                    )
                    Text(
                        text = "Access is strictly restricted to users with a valid invitation code granted by the Owner.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = inviteCode,
                        onValueChange = { inviteCode = it.uppercase() },
                        label = { Text("Invitation Code (provided by Owner)") },
                        leadingIcon = { Icon(Icons.Default.VpnKey, contentDescription = null, tint = UltraPurple) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = UltraPurple,
                            unfocusedBorderColor = UltraCardBorder
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = userName,
                        onValueChange = { userName = it },
                        label = { Text("Your Name") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = TextSecondary) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = UltraPurple,
                            unfocusedBorderColor = UltraCardBorder
                        ),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = userEmail,
                        onValueChange = { userEmail = it.trim() },
                        label = { Text("Email (if Owner assigned one)") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = TextSecondary) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = UltraPurple,
                            unfocusedBorderColor = UltraCardBorder
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (inviteCode.isBlank()) {
                                errorMessage = "Please enter your invitation code."
                                return@Button
                            }
                            isLoading = true
                            errorMessage = null
                            coroutineScope.launch {
                                val result = authRepo.loginWithInviteCode(inviteCode, userName, userEmail)
                                isLoading = false
                                result.onSuccess {
                                    onAuthenticated()
                                }.onFailure {
                                    errorMessage = it.message ?: "Authentication failed."
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = UltraPurple)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = TextPrimary)
                        } else {
                            Text("Validate Invitation Code", color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                AnimatedVisibility(visible = errorMessage != null) {
                    errorMessage?.let {
                        Text(
                            text = it,
                            color = UltraRose,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }


        }
    }
}
