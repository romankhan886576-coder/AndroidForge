package com.example.data.repository

import android.content.Context
import com.example.data.local.AdminDao
import com.example.data.local.AuditLogEntity
import com.example.data.local.InviteCodeEntity
import com.example.data.local.UserProfileEntity
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest
import java.util.UUID

class AuthRepository(private val adminDao: AdminDao, context: Context) {

    private val ownerPrefs = context.applicationContext.getSharedPreferences("ultra_owner_auth", Context.MODE_PRIVATE)

    val currentUser: Flow<UserProfileEntity?> = adminDao.getCurrentUser()
    val inviteCodes: Flow<List<InviteCodeEntity>> = adminDao.getAllInviteCodes()
    val auditLogs: Flow<List<AuditLogEntity>> = adminDao.getAuditLogs()

    fun permissionsForUser(email: String): Flow<InviteCodeEntity?> = adminDao.getInviteCodeForUser(email)

    fun isOwnerConfigured(): Boolean = ownerPrefs.contains("pin_hash")

    private fun hashPin(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    suspend fun setupOwner(email: String = "romankhan886576@gmail.com", pin: String, name: String = "ULTRA AI Owner"): Boolean {
        if (pin.length < 4) return false
        // One-time initialization. Logging out never resets or replaces the owner's credential.
        if (ownerPrefs.contains("pin_hash")) return false
        val hashed = hashPin(pin)
        ownerPrefs.edit()
            .putString("pin_hash", hashed)
            .putString("owner_email", email)
            .putString("owner_name", name)
            .apply()
        adminDao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "OWNER_SETUP",
                actor = email,
                details = "Owner account initialized."
            )
        )
        return true
    }

    suspend fun loginOwner(pin: String): Boolean {
        val storedHash = ownerPrefs.getString("pin_hash", null) ?: return false
        if (hashPin(pin) != storedHash) {
            adminDao.insertAuditLog(
                AuditLogEntity(
                    id = UUID.randomUUID().toString(),
                    action = "OWNER_LOGIN_FAILED",
                    actor = ownerPrefs.getString("owner_email", "owner") ?: "owner",
                    details = "Incorrect PIN attempt."
                )
            )
            return false
        }
        val email = ownerPrefs.getString("owner_email", "owner@ultra.ai") ?: "owner@ultra.ai"
        val name = ownerPrefs.getString("owner_name", "ULTRA AI Owner") ?: "ULTRA AI Owner"
        val session = UserProfileEntity(
            email = email,
            displayName = name,
            role = "OWNER",
            status = "ACTIVE",
            pinHash = storedHash,
            activeSessionToken = UUID.randomUUID().toString(),
            lastLoginAt = System.currentTimeMillis()
        )
        adminDao.saveUserProfile(session)
        adminDao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "OWNER_LOGIN_SUCCESS",
                actor = email,
                details = "Owner PIN verified successfully."
            )
        )
        return true
    }

    suspend fun loginWithInviteCode(code: String, userName: String, email: String): Result<UserProfileEntity> {
        val invite = adminDao.getInviteCode(code.trim().uppercase())
            ?: return Result.failure(Exception("Invalid Invitation Code. Please request access from the Owner."))

        val normalizedEmail = email.trim().lowercase().ifEmpty { "user_${code.take(6)}@ultra.ai" }
        val isFirstUse = invite.status == "ACTIVE"
        val isReturningAuthorizedUser = invite.status == "USED" &&
            invite.assignedToEmail.trim().lowercase() == normalizedEmail
        if (!isFirstUse && !isReturningAuthorizedUser) {
            return Result.failure(Exception("This invitation code is ${invite.status.lowercase()} or belongs to another user. Please contact the Owner."))
        }

        val profile = UserProfileEntity(
            email = normalizedEmail,
            displayName = userName.ifEmpty { "Invited User" },
            role = "INVITED_USER",
            status = "ACTIVE",
            activeSessionToken = UUID.randomUUID().toString(),
            lastLoginAt = System.currentTimeMillis()
        )
        adminDao.saveUserProfile(profile)

        // A code can register one identity. That same identity may use it again on this device.
        if (isFirstUse) {
            adminDao.updateInviteCode(invite.copy(status = "USED", assignedToEmail = profile.email))
        }

        adminDao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "INVITE_ACCEPTED",
                actor = profile.email,
                details = if (isFirstUse) "User registered using invitation code $code." else "Authorized invited user signed in again."
            )
        )

        return Result.success(profile)
    }

    suspend fun generateInviteCode(
        actorEmail: String,
        assignedEmail: String = "",
        canChat: Boolean = true,
        canImage: Boolean = true,
        canVideo: Boolean = true,
        canWeb: Boolean = true,
        canFiles: Boolean = true
    ): InviteCodeEntity {
        val codeChars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val randomPart = (1..6).map { codeChars.random() }.joinToString("")
        val newCode = "ULTRA-$randomPart"

        val entity = InviteCodeEntity(
            code = newCode,
            createdBy = actorEmail,
            assignedToEmail = assignedEmail,
            status = "ACTIVE",
            role = "INVITED_USER",
            canUseChat = canChat,
            canUseImageGen = canImage,
            canUseVideoGen = canVideo,
            canUseWebSearch = canWeb,
            canUseFiles = canFiles
        )
        adminDao.insertInviteCode(entity)
        adminDao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "INVITE_CODE_GENERATED",
                actor = actorEmail,
                details = "Generated invitation code $newCode for '$assignedEmail'"
            )
        )
        return entity
    }

    suspend fun revokeInviteCode(actorEmail: String, code: String) {
        val invite = adminDao.getInviteCode(code) ?: return
        adminDao.updateInviteCode(invite.copy(status = "REVOKED"))
        adminDao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "INVITE_CODE_REVOKED",
                actor = actorEmail,
                details = "Revoked invitation code $code."
            )
        )
    }

    suspend fun logout() {
        val current = adminDao.getCurrentUserSnapshot()
        if (current != null) {
            adminDao.insertAuditLog(
                AuditLogEntity(
                    id = UUID.randomUUID().toString(),
                    action = "LOGOUT",
                    actor = current.email,
                    details = "User signed out."
                )
            )
        }
        adminDao.clearUserProfile()
    }
}
