package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PromptTemplateEntity
import com.example.data.repository.UltraAiRepository
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromptLibraryScreen(
    repository: UltraAiRepository,
    onBack: () -> Unit,
    onUsePrompt: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val prompts by repository.getPrompts().collectAsState(initial = emptyList())

    var selectedCategory by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var addDialogOpen by remember { mutableStateOf(false) }

    var newPromptTitle by remember { mutableStateOf("") }
    var newPromptContent by remember { mutableStateOf("") }
    var newPromptCategory by remember { mutableStateOf("Coding") }

    val categories = listOf("All", "Coding", "Stories", "Social & Scripts", "Business", "Image Gen", "Hindi/Hinglish")

    val filteredPrompts = remember(prompts, selectedCategory, searchQuery) {
        prompts.filter {
            (selectedCategory == "All" || it.category == selectedCategory) &&
            (searchQuery.isBlank() || it.title.contains(searchQuery, true) || it.content.contains(searchQuery, true))
        }
    }

    Scaffold(
        containerColor = UltraDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Prompt Intelligence Library", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("${prompts.size} High-Performance Prompts", fontSize = 11.sp, color = UltraAmber)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { addDialogOpen = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Prompt", tint = UltraAmber)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = UltraDarkBg)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search curated prompts...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = UltraAmber,
                        unfocusedBorderColor = UltraCardBorder
                    )
                )
            }

            // Categories horizontal bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = UltraAmber,
                                selectedLabelColor = UltraDarkBg
                            )
                        )
                    }
                }
            }

            items(filteredPrompts, key = { it.id }) { prompt ->
                CyberCard(
                    borderColor = if (prompt.isFavorite) UltraAmber else UltraCardBorder
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusBadge(prompt.category, UltraAmber)
                        Row {
                            IconButton(onClick = {
                                coroutineScope.launch {
                                    repository.toggleFavoritePrompt(prompt)
                                }
                            }) {
                                Icon(
                                    imageVector = if (prompt.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "Favorite",
                                    tint = if (prompt.isFavorite) UltraAmber else TextMuted
                                )
                            }
                            IconButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Prompt", prompt.content))
                                Toast.makeText(context, "Prompt copied!", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextMuted)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(prompt.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(prompt.content, fontSize = 12.sp, color = TextSecondary, lineHeight = 17.sp)

                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { onUsePrompt(prompt.content) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = UltraAmber)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = UltraDarkBg)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Use in Chat", color = UltraDarkBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (addDialogOpen) {
        AlertDialog(
            onDismissRequest = { addDialogOpen = false },
            title = { Text("Create New Prompt") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newPromptTitle,
                        onValueChange = { newPromptTitle = it },
                        label = { Text("Prompt Title") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newPromptContent,
                        onValueChange = { newPromptContent = it },
                        label = { Text("Prompt Content") },
                        maxLines = 4
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newPromptTitle.isNotBlank() && newPromptContent.isNotBlank()) {
                        coroutineScope.launch {
                            repository.addPrompt(newPromptTitle, newPromptContent, newPromptCategory)
                        }
                        newPromptTitle = ""
                        newPromptContent = ""
                        addDialogOpen = false
                    }
                }) {
                    Text("Add to Library", color = UltraAmber)
                }
            },
            dismissButton = {
                TextButton(onClick = { addDialogOpen = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
